#!/bin/python3

n = int(input())
out = []
for _ in range(n):
    inp = input().split()
    x = float(inp[0])
    y = float(inp[1])
    m = float(inp[2])
    name = inp[3]
    if m == 0:
        continue
    
    hitposition = x - y/m
    if hitposition > x:
        out.append((hitposition, name))

out.sort()
for x in out:
    print(x[1])
