#include <bits/stdc++.h>

using namespace std;

int main() {
  int N;
  cin >> N;

  vector<pair<double, string>> ptrs;

  for (int i = 0; i < N; ++i) {
    double x, y, m;
    string s;
    cin >> x >> y >> m >> ws;
    getline(cin, s);
    
    // ignore laser pointers that do not point toward the x-axis
    if (y < 0 && m <= 0) continue;
    if (y > 0 && m >= 0) continue;

    // the laser beam is parameterized by (x + t, y + m*t) for t >= 0
    // this hits the x-axis when y + m*t = 0, i.e. t = -y/m
    ptrs.push_back({x - y/m, s});
  }
  sort(ptrs.begin(), ptrs.end());

  for (auto [_,s] : ptrs) cout << s << endl;

  return 0;
}
