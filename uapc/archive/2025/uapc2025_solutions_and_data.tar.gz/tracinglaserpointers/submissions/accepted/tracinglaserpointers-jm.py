locations = list()
names = list()

# Get input.

N = int(input())
for i in range(N):
    rawline = input()
    line = rawline.split()
    x = float(line[0])
    y = float(line[1])
    m = float(line[2])
    name = rawline[(len(line[0]) + len(line[1]) + len(line[2]) + 2):].strip()

    locations.append((x, y, m))
    names.append(name)

# Get $x$ intercepts.

intercepts = list()

for i in range(N):
    x, y, m = locations[i]
    if m == 0: # Just a line.
        continue
    if (y > 0) and (m > 0): # Pointing upwards and starting above the $x$-axis.
        continue
    if (y < 0) and (m < 0): # Pointing downwards and starting below the $x$-axis.
        continue

    intercept = x+(-y/m)
    intercepts.append((intercept, i))

# Sort the intercepts.

intercepts.sort()

# Print the result.

for i in range(len(intercepts)):
    print(names[intercepts[i][1]])
