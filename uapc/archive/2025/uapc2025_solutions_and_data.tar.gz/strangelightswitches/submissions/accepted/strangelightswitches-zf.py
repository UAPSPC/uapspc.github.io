#!/bin/python3

# rather inefficient solution that can use almost 3*N presses
# eg. on 001111111111111111111111111111111111
# is a different approach than the editorial

N = int(input())
b = list(map(int, list(input())))

sol = []

def at(i): return b[i%N]

# handy to have a function like this:
# if the press does something then record it for the output
# if not, do nothing
# also permits indexing outside of {0,1,...,N-1}, interpreting i
# as a "wrap-around" index (i.e. i = -1 is interpreted as N-1,
# i = N would be interpreted as 0)
def press(i):
  i %= N
  nb = at(i-1)^at(i+1)
  if b[i] != nb:
    sol.append(i)
    b[i] = nb

# make sure there is at least one zero
if b == "1"*N: press[0]

for _ in range(3*N):
  # zero out isolated bits
  for i in range(N):
    if [at(i-1), at(i), at(i+1)] == [0,1,0]: press(i)

  # if we see 0111, clear the first two 1-bits of it
  for i in range(N):
    if [at(j) for j in range(i, i+4)] == [0,1,1,1]:
      press(i+2)
      press(i+1)

  # if we see 0011, clear the first bit
    if [at(j) for j in range(i, i+4)] == [0,0,1,1]:
      press(i+1)
      press(i+2)
      press(i+1)

if sum(b): print(-1)
else:
  print(len(sol))
  print(*sol, sep="\n")