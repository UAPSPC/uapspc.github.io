#!/bin/python3

import sys

def greedy(switches):
    def make_left_2(i, switches):
        if switches[i] and switches[(i - 1 + n) % n] == switches[(i + 1 + n) % n]:
            if switches[(i - 1 + n) % n] and switches[(i - 2 + n) % n]:
                return True
        
        return False

    n, m, flips = len(switches), 0, []
    done_op = True

    if n == 3 and switches == [True, True, True]:
        return (-1, [])

    while done_op and len(flips) <= 2 * n and any(switches):
        done_op = False

        for i in range(n):
            if switches[i] and not make_left_2(i, switches) and switches[(i - 1 + n) % n] == switches[(i + 1 + n) % n]:
                switches[i] = switches[(i - 1 + n) % n] ^ switches[(i + 1 + n) % n]
                done_op, m = True, m + 1
                flips.append(i)

    if any(switches) and (len(flips) >= 3 * n or len(flips) == 0) and n % 3 == 0:
        return (-1, [])

    done_op = True
    while done_op and len(flips) <= 3 * n and any(switches):
        done_op = False

        for i in range(n):
            if switches[i] and switches[(i + 1 + n) % n] and not switches[(i - 1 + n) % n] and not switches[(i - 2 + n) % n]:
                flips.extend([(i - 1 + n) % n, i, (i - 1 + n) % n, (i + 1 + n) % n])
                m += 4
                switches[i] = switches[(i + 1 + n) % n] = False
                done_op = True
    
    assert not any(switches)

    return (m, flips)


N = int(input())
switches = [(True if i == '1' else False) for i in input()]

m, flips = greedy(switches)

print(m)
if m > 0:
    for i in flips:
        print(i)