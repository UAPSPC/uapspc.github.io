#include <bits/stdc++.h>
using namespace std;
typedef long long ll;
int main() {
    ll a, b, c, d, e, x;
    cin >> a >> b >> c >> d >> e >> x;

    ll e_to_d = e / 3;
    e -= e_to_d * 3;
    d += e_to_d * 2;

    ll use_d = min(x, d / 2);
    d -= use_d * 2;
    b += use_d * 3;
    x -= use_d;

    if (a % 5 >= 3) {
        a -= 3;
        b += 1;
    }

    ll base_a = a / 5;
    ll base_b = b / 3;
    ll ans = base_a + base_b + c;

    if (b < 3 && a >= (3 - b) * 3) {
        a -= (3 - b) * 3;
        b = 3;
    }

    if (b >= 3) {
        ll full_cycles = x / 4;
        b += 3 * full_cycles;
        x %= 4;

        if (e == 2 && x >= 2) {
            e = 0;
            b += 3;
            x -= 2;
        } else if (e == 1 && x >= 3) {
            e = 0;
            b += 3;
            x -= 3;
        }

        ll optimized_b = b / 3;
        ans = max(ans, optimized_b + (a / 5) + c);
    }
    cout << ans << "\n";
    return 0;
}