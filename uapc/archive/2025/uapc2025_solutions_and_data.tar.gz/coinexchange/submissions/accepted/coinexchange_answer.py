def sol(a, b, c, e, x):
    now_a = a
    now_b = b
    now_c = c
    now_e = e
    now_x = x
    
    if now_a < 0:
        return -float('inf')

    now_c += now_a // 5
    
    if now_b >= 3:
        v = min(3 - now_e, now_x)
        now_x -= v
        now_e += v
        
        if now_e == 3 and now_x > 0:
            now_x -= 1
            now_e = 0
            now_b += 3
        
        now_b += (now_x // 4) * 3
    
    return now_c + (now_b // 3)

def max_c(a, b, c, d, e, x):
    td = e // 3
    e_new = e - td * 3
    d += td * 2
    
    tb = min(d // 2, x)
    x_new = x - tb
    b_new = b + tb * 3
    
    mod = b_new % 3
    vb = 0 if mod == 0 else 3 - mod
    va = a - vb * 3
    adj_b = b_new + vb
    
    case1 = sol(a, b_new, c, e_new, x_new)
    case2 = sol(va, adj_b, c, e_new, x_new)
    
    return max(case1, case2)

a, b, c, d, e, x = map(int, input().split())
print(max_c(a, b, c, d, e, x))