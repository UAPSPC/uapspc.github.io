#include<bits/stdc++.h>
using namespace std;using ll=long long;using pii=pair<int,int>;using pll=pair<ll,ll>;
using i128=__int128;using ull=unsigned long long;
const int M=998244353,K=1e6;const ll inf=1e17;
ll res[K];
struct S
{		
    struct node
    {
        ll A,B,C,D,E,X,res=0,v;
        void ini(){cin>>A>>B>>C>>D>>E>>X;}
        ll rs()
        {
            v=E/3;E-=v*3;D+=v*2;
            v=min(D/2,X);X-=v,B+=v*3;
            auto nd=*this;v=(3-B%3);nd.A-=v*3;nd.B+=v;
            return max(sol(),nd.sol());          
        }
        ll sol()
        {           
            if(A<0)return -inf;C+=A/5;
            if(B>=3)
            {
                v=min(3-E,X);X-=v,E+=v;
                if(E==3&&X)X--,E-=3,B+=3;
                B+=X/4*3;
            }
            return C+B/3;           
        }
    };
    void solve()
	{
        node A;A.ini();cout<<A.rs()<<'\n';
    }
};
void precal(){}
int main()
{
	//ios::sync_with_stdio(0);cin.tie(0);precal();
    //freopen("1.in","r",stdin);
    int t=1;//cin>>t;
    while(t--){S SS;SS.solve();}
}