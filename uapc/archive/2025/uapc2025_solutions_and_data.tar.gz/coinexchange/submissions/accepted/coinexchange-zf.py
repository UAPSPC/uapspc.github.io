#!/bin/python3

# Using less-than-optimized constants but it should still work.

A, B, C, D, E, X = map(int, input().split())

# create max # of C assuming A is 0
def solve(B, D, E, X):
  # greedily push any remaining E and D through their transitions
  ED = E//3
  E, D = E-3*ED, D+2*ED

  DB = min(D//2, X)
  D, B, X = D-2*DB, B+3*DB, X-DB

  # now greedily exchange around the cycle 
  if B >= 9:
    # we can push 9 B -> 12 E -> 8 D -> 12 B which uses DB 4 times, iterate X//4 times in total
    cyc = X//4
    B, X = B+3*cyc, X-4*cyc
  
  # B//3 is what we would get if we cashed out now
  ans = B//3

  # also try using BE but only if X >= 1
  if X >= 1 and B >= 3: ans = max(ans, solve(B-3,D,E+4,X))

  return ans

ans = -1

# guess the number of AB transitions to use, cash out the remaining A as A->C, and solve the resulting problem
for AB in range(min(15+9, A//3+1)):
  # print(AB, C + (A-3*AB)//5 + solve(B+AB, D, E, X))
  ans = max(ans, C + (A-3*AB)//5 + solve(B+AB, D, E, X))

assert ans != -1 # sanity check
print(ans)
