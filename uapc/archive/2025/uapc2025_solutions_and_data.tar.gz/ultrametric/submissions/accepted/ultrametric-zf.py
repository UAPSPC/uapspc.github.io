#!/bin/python3

# Two main observations (proof omitted)
# Lemma: distances with the first 2 properties in the statement form an ultrametric
# if and only if for any (u,v) there is no path from u to v using only distance < d(u,v) steps
# Lemma: given distances can be completed to an ultrametric if and only if
# for any given d(u,v) there is no path from u to v using only given distances that are < d(u,v)

N, M = map(int, input().split())
e = {}
for _ in range(M):
  u,v,w = map(int, input().split())
  if w not in e: e[w] = []
  e[w].append((u,v))

uf = list(range(N))
sz = [1]*N

def find(u):
  if uf[u] != u: uf[u] = find(uf[u])
  return uf[u]

ans = "possibly"

for w in sorted(e.keys()):
  for u,v in e[w]:
    if find(u) == find(v):
      ans = "not"
  for u,v in e[w]:
    pu, pv = find(u), find(v)
    if pu != pv:
      if sz[pu] > sz[pv]: pu, pv = pv, pu
      uf[pu] = pv
      sz[pv] += sz[pu]
  
print(ans,"ultrametric")