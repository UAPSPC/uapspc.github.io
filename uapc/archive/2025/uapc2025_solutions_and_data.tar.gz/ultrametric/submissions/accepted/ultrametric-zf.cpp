#include <bits/stdc++.h>

using namespace std;

int main() {
  map<int, vector<pair<int,int>>> edges;
  int N, M;
  cin >> N >> M;

  for (int i = 0; i < M; ++i) {
    int u, v, l;
    cin >> u >> v >> l;
    edges[l].push_back({u,v});
  }

  vector<int> uf(N);
  iota(uf.begin(), uf.end(), 0);

  function<int(int)> find = [&](int v) { return v == uf[v] ? v : (uf[v] = find(uf[v])); };

  string ans = "possibly";
  for (const auto& [_,e] : edges) {
    for (auto [u,v] : e) if (find(u) == find(v)) ans = "not";
    for (auto [u,v] : e) uf[find(u)] = find(v);
  }
  
  cout << ans << " ultrametric" << endl;
  return 0;
}
