#include <bits/stdc++.h>
using namespace std;


#define ll long long
#define rep(i, a, b) for(int i = a; i < (b); ++i)
#define all(x) begin(x), end(x)
#define pb(x) push_back(x)
#define eb(x, y) emplace_back(x, y)
#define mp(x, y) make_pair(x, y)
#define sz(x) (int)(x).size()
typedef vector<int> vi;
typedef pair<int, int> pii;

vector<int> A;
int find(int x){return A[x]=(x==A[x]?x:find(A[x]));}
void merge(int x, int y){A[find(x)]=find(y);}

int main(){
    map<int, vector<pii>> e;

    int n, m; cin >> n >> m;
    
    rep(i, 0, m){
        int u, v, l; cin >> u >> v >> l;
        e[l].eb(u, v);
    }

    A.resize(n);
    iota(begin(A),end(A),0);

    // If there exists a path from u to v with all d(x, y) <= l 
    // then d(u, v) <= l for X to be ultrametric
    for(auto iter = e.begin(); iter != e.end(); ++iter){
        vector<pii> edges = iter->second;
        for(pii edge : edges){
            int u, v; tie(u, v) = edge;
            // if there is already a path from u to v then d(u, v) > l (not ultrametric)
            if(find(u) == find(v)){
                cout << "not ultrametric" << endl;
                return 0;
            }
        }

        for(pii edge : edges){
            int u, v; tie(u, v) = edge;
            merge(u, v);
        }
    }

    cout << "possibly ultrametric" << endl;
    return 0;
}