#!/bin/python3

n = int(input())
a = [int(x) for x in input().split()]

r = [a[0]]
for i in range(1, len(a)):
    if a[i] >= r[-1]:
        r.append(a[i])
print(*r)