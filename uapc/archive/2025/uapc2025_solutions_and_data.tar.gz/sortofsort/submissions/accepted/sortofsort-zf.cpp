#include <bits/stdc++.h>

using namespace std;

int main() {
  int N;
  cin >> N;
  vector<int> a(N);
  for (int& x : a) cin >> x;

  int prev = a[0]; // our "running max"
  for (int i = 0; i < N; ++i) {
    if (a[i] >= prev) {
      if (i) cout << ' ';
      cout << a[i];
      prev = a[i];
    }
  }
  cout << endl;

  return 0;
}
