#include <bits/stdc++.h>
using namespace std;

#define ll long long
#define rep(i, a, b) for(int i = a; i < (b); ++i)
#define all(x) begin(x), end(x)
#define pb(x) push_back(x)
#define mp(x, y) make_pair(x, y)
#define sz(x) (int)(x).size()
typedef vector<int> vi;

int main(){
    int n; cin >> n;
    vi a(n);
    for(auto& x : a)
        cin >> x;

    vi r;
    rep(i, 1, n)
        if((!sz(r) && a[i] >= a[0]) || (sz(r) && a[i] >= r[sz(r)-1])) r.pb(a[i]);
    
    cout << a[0];
    for(auto x : r)
        cout << " " << x;
    cout << '\n';

    return 0;
}