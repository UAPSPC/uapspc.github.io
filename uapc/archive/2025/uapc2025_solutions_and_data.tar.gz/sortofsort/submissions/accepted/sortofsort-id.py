#!/bin/python3
n = int(input())
a = list(map(int, input().split()))
x = a[0]
for y in a:
    if y >= x:
        print(y, end=" ")
    x = max(x, y)
print()