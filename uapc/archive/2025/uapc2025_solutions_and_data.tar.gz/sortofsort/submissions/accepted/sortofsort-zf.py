#!/bin/python3

input()
a = list(map(int, input().split()))

out = [a[0]]
for x in a:
  if x >= out[-1]: out.append(x)
print(*out[1:])
