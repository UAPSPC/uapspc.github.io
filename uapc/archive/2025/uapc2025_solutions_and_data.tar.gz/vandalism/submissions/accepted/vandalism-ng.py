#!/bin/python3

s, uapc = input(), list('UAPC')
print(''.join(sorted(set(uapc) - set(s), key=uapc.index)))