#!/bin/python3
s = input()
t = "UAPC"
for c in t:
    if c not in s:
        print(c, end="")
print()