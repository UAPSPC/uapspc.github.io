// testing if accidentally printing the null terminator will pass (it should)

#include <bits/stdc++.h>

using namespace std;

int main() {
  string s;
  cin >> s;

  for (char c : string("UAPC"))
    if (s.find(c) == -1)
      cout << c;
    
  cout << endl;

  return 0;
}
