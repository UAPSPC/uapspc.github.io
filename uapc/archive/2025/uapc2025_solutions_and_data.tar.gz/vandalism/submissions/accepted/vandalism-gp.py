#!/bin/python3
s = input()
for c in "UAPC":
    if c not in s:
         print(c,end='')
print()