#include <bits/stdc++.h>
using namespace std;

#define rep(i, a, b) for(int i = a; i < (b); ++i)
#define all(x) begin(x), end(x)
#define sz(x) (int)(x).size()
typedef long long ll;
typedef pair<int, int> pii;
typedef vector<int> vi;
#define pb push_back
#define mp make_pair


int main() {
	cin.tie(0)->sync_with_stdio(0);
	cin.exceptions(cin.failbit);

	string s;
	cin >> s;
	int n;
	cin >> n;
	int out = 0;
	rep(i, 0, n) {
		string t;
		cin >> t;
		rep(j, 0, sz(t)) {
			bool match = true;
			if (j + sz(s) - 1 >= sz(t)) break;
			rep(k, 0, sz(s)) {
				if (s[k] != t[j+k]) match = false;
			}
			if (match) out++;
		}
		
	}
	cout << out << endl;
}