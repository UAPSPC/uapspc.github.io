#!/bin/python3

w, m, s = input(), input(), input()
print(sum(s.startswith(w,i) for i in range(len(s))))