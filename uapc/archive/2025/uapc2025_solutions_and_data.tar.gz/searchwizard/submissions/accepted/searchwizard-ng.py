#!/bin/python3

w, m, s = input(), input(), input()
cnt = 0

for i in range(len(s)):
    if s[i:i + len(w)] == w:
        cnt += 1

print(cnt)