#include <bits/stdc++.h>

using namespace std;

int main() {
  string s, m, t;
  cin >> s >> m >> ws;
  getline(cin, t);

  int ans = 0;

  for (int j = 0; j + s.size() <= t.size(); ++j) {
    bool ok = true;
    for (int k = 0; k < s.size(); ++k)
      if (s[k] != t[j+k]) ok = false;
    if (ok) ++ans;
  }

  cout << ans << endl;
  return 0;
}
