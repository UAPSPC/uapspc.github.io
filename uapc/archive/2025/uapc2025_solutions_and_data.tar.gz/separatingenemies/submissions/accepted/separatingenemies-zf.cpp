/*
	OK, this is a long explanation. See separatingenemies-id.cpp for an implementation of the
	solution from the solution slides. This implementation is for a different algorithm.

	DISCLAIMER: this was not the expected solution, it was simply me having fun with my favourite way
	to view combinatorial optimization problems

	Starting point: LP duality.
	Consider the linear program with a variable x(e) for every edge e.

	minimize: sum_e cost(e)*x(e)
	subject to: sum_{e between s and t} x(e) >= 1 for each pair of enemies s, t
	x >= 0

	An optimal integer solution only has values {0,1} for variables and corresponds to an
	optimal solution to this problem.

	Lemma: There is an optimal LP solution that is also an integer solution.
	(i.e. integer program optimum value == linear program optimum value == UAPC problem optimum value!)
	Proof: Every row of the constraint matrix has all of its 1s appearing consecutively. Google
	"consecutive 1s property" for linear programming to find a proof of why this means the LP has an
	integral optimum.

	Now consider the dual of this LP where we have a variable y(s,t) for every pair of enemies.
	maximize: sum_{(s,t)} y(s,t)
	subject to: sum_{(s,t) such that e is between s and t} y(s,t) <= c(e) for each edge e
	y >= 0

	Primal/Dual algorithm:
	Initially set y(s,t) = 0 for all entries.
	For each (s,t) in <= order of t:
	  if all edges between s,t have their dual constraint not yet tight
		  increase y(s,t) until at least one edge between s and t has its dual constraint go tight
	C := all edges whose dual constraint is tight (easy to prove is a feasible solution, but maybe not optimal)
	For each edge e in C from right to left order (i.e. decreasing index)
	  If C - {e} is still a feasible solution the remove e from C

	Claim: C is a feasible multicut solution whose value is the sum of all dual variables.
	i.e. the {0,1} solution corresponding to C is an LP solution whose value equals the value
	of the feasible dual solution y() we grew. i.e. both must be optimal for their respective LPs
	by LP duality.

	Proof sketch: Every edge in the final set C has its dual constraint being tight by construction.
	More importantly, for every pair (s,t) with y(s,t) > 0 (i.e. we raised it) we have exactly one
	edge between s and t in C. This shows the "complementary slackness" conditions for LP duality hold,
	meaning we have an optimal primal/dual pair of solutions.

	Algorithm:
	Well, we don't actually need to construct C since we just need the value. We just have to simulate
	the part where we raise y(s,t) values. We can do this with a lazy segtree over the edges where
	we are storing the "slack" in the dual constraints on the edges. Initially setting y(s,t) = 0 for all
	s,t means we have slack c(e) for each edge.

	The amount we raise some y(s,t) equals the minimum slack of the edges it spans. Query the segtree for
	this. Then do a range update where we subtract this value from all edges spanned by y(s,t). That's it!
	The final solution is the sum of the minimum values of all slacks we see in the algorithm.
*/

#include <bits/stdc++.h>

using namespace std;

// BEGIN KACTL lazy segree
// not modified (apart from removing macros)
// it supports range max and range setting / adding

const int inf = 1e9;
struct Node {
	Node *l = 0, *r = 0;
	int lo, hi, mset = inf, madd = 0, val = -inf;
	Node(int lo,int hi):lo(lo),hi(hi){} // Large interval of -inf
	Node(vector<int>& v, int lo, int hi) : lo(lo), hi(hi) {
		if (lo + 1 < hi) {
			int mid = lo + (hi - lo)/2;
			l = new Node(v, lo, mid); r = new Node(v, mid, hi);
			val = max(l->val, r->val);
		}
		else val = v[lo];
	}
	int query(int L, int R) {
		if (R <= lo || hi <= L) return -inf;
		if (L <= lo && hi <= R) return val;
		push();
		return max(l->query(L, R), r->query(L, R));
	}
	void set(int L, int R, int x) {
		if (R <= lo || hi <= L) return;
		if (L <= lo && hi <= R) mset = val = x, madd = 0;
		else {
			push(), l->set(L, R, x), r->set(L, R, x);
			val = max(l->val, r->val);
		}
	}
	void add(int L, int R, int x) {
		if (R <= lo || hi <= L) return;
		if (L <= lo && hi <= R) {
			if (mset != inf) mset += x;
			else madd += x;
			val += x;
		}
		else {
			push(), l->add(L, R, x), r->add(L, R, x);
			val = max(l->val, r->val);
		}
	}
	void push() {
		if (!l) {
			int mid = lo + (hi - lo)/2;
			l = new Node(lo, mid); r = new Node(mid, hi);
		}
		if (mset != inf)
			l->set(lo,hi,mset), r->set(lo,hi,mset), mset = inf;
		else if (madd)
			l->add(lo,hi,madd), r->add(lo,hi,madd), madd = 0;
	}
};

// END KACTL lazy segtree


int main() {
  int N;
  cin >> N;

  // will store negative of values in range max lazy segtree
  vector<int> c(N-1);
  for (int& x : c) {
    cin >> x;
    x = -x;
  }
  Node *tr = new Node(c, 0, c.size());

  int M;
  cin >> M;

  // sort enemies by their rightmost point
  vector<pair<int,int>> e(M);
  for (auto& [s,t] : e) {
    cin >> s >> t;
    if (s < t) swap(s,t);
  }
  sort(e.begin(), e.end());

  // for each enemy, uniformly reduce the costs/slacks of all edges between them
  // until one becomes zero: add the amount reduced to the answer 
  int ans = 0;
  for (auto [s,t] : e) {
    assert(s > t);
    int val = -tr->query(t-1,s-1);
		// it could be val == 0 (i.e. there was no slack on some edges between s,t)
		// but that just means the next two steps do nothing
    ans += val;
    tr->add(t-1, s-1, val);
  }

  cout << ans << endl;

  return 0;
}