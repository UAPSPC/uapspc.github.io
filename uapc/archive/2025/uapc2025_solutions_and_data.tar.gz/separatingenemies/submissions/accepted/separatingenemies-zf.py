#!/bin/python3

# See separatingenemies-zf.cpp for a discussion of my approach.
# This is an implementation of it that does not use lazy segtrees.
# It simply simulates the behaviour of that solution but only needs heaps.

import heapq

input()
costs = [0] + list(map(int, input().split()))
en = [tuple(map(int, input().split())) for _ in range(int(input()))]

rhs, ans, heap = 0, 0, []
for s, t in sorted(en, key = lambda x : x[1]):
  while rhs < t:
    heapq.heappush(heap, (ans+costs[rhs], rhs))
    rhs += 1
  while heap[0][1] < s: heapq.heappop(heap)
  ans = heap[0][0]

print(ans)
