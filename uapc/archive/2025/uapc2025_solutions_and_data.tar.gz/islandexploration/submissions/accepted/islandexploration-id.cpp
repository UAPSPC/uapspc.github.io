#include <bits/stdc++.h>
using namespace std;

#define rep(i, a, b) for(int i = a; i < (b); ++i)
#define all(x) begin(x), end(x)
#define sz(x) (int)(x).size()
typedef long long ll;
typedef pair<int, int> pii;
typedef vector<int> vi;
#define pb push_back
#define mp make_pair

#define MAXN 110
char a[MAXN][MAXN];
bool seen[MAXN][MAXN];

int out = 0;
void dfs(int x, int y) {
	if (seen[x][y] || a[x][y] == '.') return;
	out++;
	seen[x][y] = true;
	rep(xx, x-1, x+2) rep(yy, y-1, y+2) {
		if (xx != x && yy != y) continue;
		dfs(xx, yy);
	}
}


int main() {
	cin.tie(0)->sync_with_stdio(0);
	cin.exceptions(cin.failbit);

	int n, m;
	cin >> n >> m;
	rep(i, 0, n) rep(j, 0, m) cin >> a[i][j];

	rep(i, 0, n) rep(j, 0, m) if (a[i][j] == 'S') dfs(i, j);
	cout << out << endl;
}