#include <bits/stdc++.h>

using namespace std;

using pii = pair<int,int>;

bool reached[100][100];

int main() {
  int R, C;
  cin >> R >> C;

  int sr, sc;
  vector<string> g(R);
  for (int i = 0; i < R; ++i) {
    cin >> g[i];
    for (int j = 0; j < C; ++j)
      if (g[i][j] == 'S') {
        sr = i;
        sc = j;
      }
  }

  queue<pii> q;
  q.push({sr,sc});
  reached[sr][sc] = true;
  int ans = 1;

  int dr[] = {-1, 1, 0, 0}, dc[] = {0, 0, -1, 1};
  while (q.size() > 0) {
    auto [r,c] = q.front();
    q.pop();

    for (int i = 0; i < 4; ++i) {
      int nr = r + dr[i], nc = c + dc[i];
      if (!reached[nr][nc] && g[nr][nc] == '#') {
        reached[nr][nc] = true;
        ++ans;
        q.push({nr,nc});
      }
    }
  }

  cout << ans << endl;

  return 0;
}