#!/bin/python3

# classic graph search, this one is not even necessarily a BFS or DFS
# it just maintains a set of seen cells and a set of cells to explore
# (sort of like the queue in a BFS, but not structured first-in/first-out)
# anyway, any graph search should work

R, C = map(int, input().split())

g = [input() for _ in range(R)]

for i in range(R):
  for j in range(C):
    if g[i][j] == 'S':
      start = (i,j)

reached = {start}
boundary = {start}
while boundary:
  r, c = boundary.pop()
  for dr, dc in [(-1,0), (1,0), (0, -1), (0,1)]:
    nr, nc = r+dr, c+dc
    if g[nr][nc] == '#' and (nr, nc) not in reached:
      reached.add((nr,nc))
      boundary.add((nr,nc))

print(len(reached))
