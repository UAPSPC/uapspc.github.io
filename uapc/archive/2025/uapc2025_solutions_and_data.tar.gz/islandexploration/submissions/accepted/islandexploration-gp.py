import sys
sys.setrecursionlimit(100000)

r, c = map(int, input().split())

grid = [[c for c in input()] for _ in range(r)]

def flood(i, j):
    grid[i][j] = '.'

    tot = 1

    for di, dj in [(-1, 0), (1, 0), (0, -1), (0, 1)]:
        if i + di >= 0 and i + di < r and j + dj >= 0 and j + dj < c:
            if grid[i+di][j+dj] == '#':
                tot += flood(i+di, j+dj)

    return tot


for i in range(r):
    for j in range(c):
        if(grid[i][j] == 'S'):
            print(flood(i, j))
            sys.exit(0)