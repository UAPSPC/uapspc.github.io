#include <bits/stdc++.h>

using namespace std;

int main() {
  int N, L, W;
  cin >> N >> L >> W;

  vector<int> x(N), y(N);
  for (int i = 0; i < N; ++i) cin >> x[i] >> y[i];

  auto solve = [&](vector<int> c, int D) {
    vector<pair<int,int>> vc(N);
    vector<int> sol(N);
    for (int i = 0; i < N; ++i) vc[i] = {c[i], i};
    sort(vc.begin(), vc.end());
    int prev = -2;
    for (auto [v,i] : vc) {
      if (prev < v) prev = v+D;
      sol[i] = prev;
    }
    return sol;
  };
  
  auto xv = solve(x, L), yv = solve(y, W);

  set<pair<int,int>> nails;
  for (int i = 0; i < N; ++i) nails.insert({xv[i], yv[i]});

  cout << nails.size() << endl;
  for (auto [x,y] : nails) cout << x << ' ' << y << endl;

  return 0;
}
