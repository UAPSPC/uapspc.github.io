#!/bin/python3

# each rectangle spans exactly one point (x,y) such that
# x mod L is 1 and y mod W is 1, we can compute it directly

N, L, W = map(int, input().split())

ans = set()
for _ in range(N):
  x, y = map(int, input().split())
  ans.add(((x+L-1)//L*L + 1, (y+W-1)//W*W + 1))

print(len(ans))
for p in ans: print(*p)
