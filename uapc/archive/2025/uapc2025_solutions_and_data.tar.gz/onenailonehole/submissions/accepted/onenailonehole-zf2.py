#!/bin/python3

# solves 1D cases corresponding the the x-intervals and, separately, the y-intervals
# for the rectangles and then merges these to get the final solution

N, L, W = map(int, input().split())

pts = [tuple(map(int, input().split())) for _ in range(N)]

# given intervals of length D and starting points c[0], c[1], ..., c[N-1]
# finds a set of points such that each interval touches exactly one point
# it sorts the intervals from left-to-right
# for each interval in this order, if it is not yet touching a point then
# add its rightmost point: this will not touch any intervals that were previously scanned
# (i.e. we do not cause an interval to be touched by >= 2 points) because all intervals have
# the same length
def solve(c, D):
  prev = -2
  sol = [-1]*N
  for v, i in sorted([(c[j],j) for j in range(N)]):
    if prev < v: prev = v+D
    sol[i] = prev
  return sol

xv = solve([p[0] for p in pts], L)
yv = solve([p[1] for p in pts], W)

ans = set()
for i in range(N): ans.add((xv[i], yv[i]))
print(len(ans))
for p in ans: print(*p)
