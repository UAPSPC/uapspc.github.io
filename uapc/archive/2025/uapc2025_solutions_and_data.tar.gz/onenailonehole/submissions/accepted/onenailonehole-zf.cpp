#include <bits/stdc++.h>

using namespace std;

int main() {
  int N, L, W;
  cin >> N >> L >> W;

  set<pair<int,int>> nails;
  for (int i = 0; i < N; ++i) {
    int x, y;
    cin >> x >> y;
    nails.insert({(x+L-1)/L*L + 1, (y+W-1)/W*W + 1});
  }

  cout << nails.size() << endl;
  for (auto [x,y] : nails) cout << x << ' ' << y << endl;

  return 0;
}