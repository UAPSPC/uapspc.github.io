#!/bin/python3
from math import ceil

p = int(input())
s = input()
if p == 2:
    print(s)
else:
    lb = 0
    ub = 1
    for i in range(1, len(s)):
        if s[i] == '1':
            lb = (lb + ub) / 2
        else:
            ub = (lb + ub) / 2
    out = int(ceil(lb*p))
    if (out % 2) != (int(s[0]) % 2):
        out += 1
    print(out)
