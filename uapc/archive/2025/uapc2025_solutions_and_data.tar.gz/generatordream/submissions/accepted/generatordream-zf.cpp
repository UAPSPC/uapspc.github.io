/*
  Constructs a fraction F such that F*p is the answer (or at least one off of the answer,
  depending on the first given bit).
*/

#include <bits/stdc++.h>

using namespace std;

using ll = long long;

ll solve() {
  ll p;
  string b;
  cin >> p >> b;

  // check if x is the solution
  auto check = [&](ll x) {
    for (int i = 0; i < b.size(); ++i) {
      if (((x%2) == 1) != (b[i] == '1')) return false;
      x = (x*2)%p;
    }
    return true;
  };

  ll numer = 0, denom = 1<<(b.size()-1);
  for (int i = 1; i < b.size(); ++i) numer = (numer*2)+(b[i]=='1');

  // construct something very close to the answer, off by at most 1
  ll x = p*numer/denom;

  // if this value x did not solve the problem, increase it
  while (!check(x)) x = (x+1)%p;

  return x;
}

int main() {
  cout << solve() << endl;
}