p = int(input())
b = input()

x = int(b[0])

# learn the numbers x_1, x_2, ...
for i in range(1, len(b)):
    x *= 2
    if b[i] == '1':
        x -= p
    mask = 2**(i+1) - 1
    x = x & mask

# recover original x from x_log(p)
for i in range(len(b)-1, 0, -1):
    if b[i] == '1':
        x += p
    x = int(x/2)

print(x)