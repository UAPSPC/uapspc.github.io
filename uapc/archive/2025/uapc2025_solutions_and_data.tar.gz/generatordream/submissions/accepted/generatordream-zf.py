#!/bin/python3

# another binary search approach
# observation: the bit string formed by b2,b3,... (i.e. ignoring the first bit)
# generated from x will be decreasing as x increases, so binary search

P = int(input())
B = input()

def gen(x):
  ans = []
  for i in range(len(B)):
    xi = (2**i)*x
    ans.append("1" if (2**i)*(xi%P%2) else "0")
  return "".join(ans)

lo, hi = 0, P

while lo+5 < hi:
  mid = (lo+hi)//2
  if (mid&1) != (B[0] == "1"): mid ^= 1

  if gen(mid) > B: hi = mid
  else: lo = mid

while gen(lo) != B: lo += 1

print(lo)