#!/bin/python3

t, h = map(int, input().split())
print((h + (t - h/2)) if t > h/2 else ((2*h*t)**0.5))