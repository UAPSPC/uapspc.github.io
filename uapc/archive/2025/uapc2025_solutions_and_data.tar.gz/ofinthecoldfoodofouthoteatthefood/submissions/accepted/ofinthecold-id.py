#!/bin/python3

t, h = map(int, input().split())

if t > h/2:
    print("%.10f" % (h + (t - h/2)))
else:
    print("%.10f" % ((2*h*t)**0.5))