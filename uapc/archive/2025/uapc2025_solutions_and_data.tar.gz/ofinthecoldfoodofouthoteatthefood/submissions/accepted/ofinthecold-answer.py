import math

t, h = map(int, input().split())
half = h / 2.0

if t <= half:
    time = math.sqrt(2 * h * t)
else:
    time = t + half

print("{0:.10f}".format(time))