#include <bits/stdc++.h>

using namespace std;

int main() {
  float T, H;
  cin >> T >> H;

  if (T > H/2) cout << H + (T-H/2) << endl;
  else cout << sqrt(2*H*T) << endl;

  return 0;
}