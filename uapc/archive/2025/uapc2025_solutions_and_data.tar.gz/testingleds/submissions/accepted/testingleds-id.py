#!/bin/python3
from sys import exit
n = int(input())
a = sorted([list(map(int, input().split())) for _ in range(n)])
for x in a:
    if x[1] == 0:
        print(x[0])
        exit(0)
print(-1)