#include <bits/stdc++.h>

using namespace std;

int main() {
  int N;
  bool off = false;
  int sol;

  cin >> N;
  for (int i = 0; i < N; ++i) {
    int M, O;
    cin >> M >> O;
    if (O == 0) {
      if (off) sol = min(sol, M);
      else {
        off = true;
        sol = M;
      }
    }
  }

  if (!off) cout << -1 << endl;
  else cout << sol << endl;
}