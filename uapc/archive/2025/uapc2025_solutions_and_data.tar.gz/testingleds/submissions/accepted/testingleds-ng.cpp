#include <bits/stdc++.h>

using namespace std;

unsigned long long n, m, o;
unsigned long long lowest = 18446744073709551615ULL;
bool was_off = false;

int main() {

    cin >> n;

    for (size_t i = 0; i < n; i++) {
        cin >> m >> o;
        if (o) continue;

        lowest = min(lowest, m);
        was_off = true;
    }

    if (was_off) cout << lowest << endl;
    else cout << -1 << endl;

    return 0;
}