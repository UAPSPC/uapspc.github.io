#!/bin/python3

result = -1
for i in range(int(input())):
    w, o = map(int, input().split())
    if(not o): result = min((result if result!=-1 else w), w)
print(result)