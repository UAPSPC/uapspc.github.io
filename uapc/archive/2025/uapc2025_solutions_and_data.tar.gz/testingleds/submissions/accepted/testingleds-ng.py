#!/bin/python3

N = int(input())
was_off = False
lowest = 2**64

for _ in range(N):
    m, o = map(int, input().split())

    if not o:
        lowest = min(lowest, m)
        was_off = True

print(lowest if was_off else -1)
