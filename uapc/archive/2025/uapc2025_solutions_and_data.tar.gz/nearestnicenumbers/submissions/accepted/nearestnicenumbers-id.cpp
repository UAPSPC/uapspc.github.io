#include <bits/stdc++.h>
using namespace std;

#define rep(i, a, b) for(int i = a; i < (b); ++i)
#define all(x) begin(x), end(x)
#define sz(x) (int)(x).size()
typedef long long ll;
typedef long double ld;
typedef pair<int, int> pii;
typedef vector<int> vi;
#define pb push_back
#define mp make_pair

#define MAXN 1'000'010
ld a[MAXN];

int main() {
	cin.tie(0)->sync_with_stdio(0);
	cin.exceptions(cin.failbit);

	int n, d;
	cin >> n >> d;
	rep(i, 0, n) {
		ld x;
		cin >> x;

		// f/d = x
		// f = x*d
		int f = x*d;
		a[i] = x - f/((ld)d);
		//cout << i << ' ' << a[i] << endl;
	}
	sort(a, a+n);
	ld x = 0;
	ld y = 0;
	int lptr = 0;
	int rptr = n-1;
	while (lptr <= rptr) {
		if (x < y) {
			x += a[lptr];
			lptr++;
		} else {
			y += (1/((ld) d))-a[rptr];
			rptr--;
		}
	}
	//cout << fixed << setprecision(10) << x << ' ' << y << endl;
	cout << fixed << setprecision(10) << 2*x*d << endl;
}
