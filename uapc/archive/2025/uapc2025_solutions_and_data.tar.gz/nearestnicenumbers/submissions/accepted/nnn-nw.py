N, D = map(int, input().split())
x = [float(input()) for _ in range(N)]
f = [int(x_i * D) for x_i in x]
rem = D - sum(f)
if rem > 0:
    diff = [(x[i]*D - f[i], i) for i in range(N)]
    diff.sort(reverse=True)
    for j in range(rem):
        _, idx = diff[j]
        f[idx] += 1
print("%.10f" % sum(abs(x_i*D - f_i) for x_i, f_i in zip(x, f)))
