/*
  For each x[i], let N[i] denote the integer with N[i]/D <= x[i] <= (N[i]+1)/D.
  Claim: each x[i] will be rounded to either N[i]/D or (N[i]+1)/D (see slides for justification)
  So initially round each x[i] to N[i]/D. Then compute how many should actually have been rounded
  up instead (i.e. rem_D := sum_i N[i] - D of the x[i] should have been rounded up instead).
  For each i, compute the increase (or maybe even decrease) in score if we rounded it up instead.
  Pick the rem_D of these that are best.
*/

#include <bits/stdc++.h>

using namespace std;

using ll = long long;

int main() {
  ll N, D;
  cin >> N >> D;
  
  ll rem_D = D;
  double ans = 0;
  vector<double> inc(N);

  for (int i = 0; i < N; ++i) {
    double x, f;
    cin >> x;
    f = ll(D*x);
    rem_D -= f;
    ans += (x-f/D);
    inc[i] = ((f+1)/D - x) - (x-f/D);
  }
  
  sort(inc.begin(), inc.end());
  for (int i = 0; i < rem_D; ++i) ans += inc[i];

  cout << fixed << setprecision(10) << ans*D << endl;


  return 0;
}
