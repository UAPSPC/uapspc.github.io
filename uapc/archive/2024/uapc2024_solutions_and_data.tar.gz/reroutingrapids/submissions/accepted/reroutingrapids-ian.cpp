#include <bits/stdc++.h>
using namespace std;

#define rep(i, a, b) for(int i = a; i < (b); ++i)
#define all(x) begin(x), end(x)
#define sz(x) (int)(x).size()
typedef long long ll;
typedef pair<int, int> pii;
typedef vector<int> vi;
#define pb push_back
#define mp make_pair

#define MAXN 100'000

int n;
vi adj[MAXN];
int root;
int deg;

int dfs(int curr) {
    int numto = sz(adj[curr]);
    for (int nxt : adj[curr]) numto += dfs(nxt);
    return max(0, numto-deg);
}

int main() {
	cin.tie(0)->sync_with_stdio(0);
	cin.exceptions(cin.failbit);

    cin >> n;
    rep(i, 0, n) {
        int x;
        cin >> x;
        x--;
        if (x != -1) adj[x].pb(i);
        else root = i;
    }

    if (n == 1) {
        cout << 0 << endl;
        return 0; // edge case
    }

    int lo = 0;
    int hi = n;
    while (hi-lo > 1) {
        int mid = (hi + lo) / 2;
        deg = mid;
        if (dfs(root) == 0) hi = mid;
        else lo = mid;
    }
    cout << hi << endl;
}