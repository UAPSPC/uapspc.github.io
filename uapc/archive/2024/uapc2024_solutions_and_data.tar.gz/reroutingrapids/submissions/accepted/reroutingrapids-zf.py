#!/bin/python3

# avoiding recursion since Python tends to not recurse that deep very well
# even with sys.setrecursionlimit (interpreter crashes)


N = int(input())
parent = [-1] + list(map(int, input().split()))
ch = [[] for _ in range(N+1)]
for i in range(1, N+1): ch[parent[i]].append(i)


def check(k):
  up = [0]*(N+1)
  for v in ord[::-1]: up[parent[v]] += 1 + max(0, up[v] - k)
  return up[root] <= k


root = parent.index(0)

ord = []
open = [root]
seen = set()
while open:
  ord.append(open.pop())
  open.extend(ch[ord[-1]])


lo, hi = -1, N
while lo+1 < hi:
  mid = (lo+hi)//2
  if check(mid): hi = mid
  else: lo = mid

print(hi)
