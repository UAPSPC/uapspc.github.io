n, q = map(int, input().split())
names = [input().split() for _ in range(n)]
queries = [input() for _ in range(q)]
for q in queries:
    matches = []
    for n in names:
        if q[0] == n[0][0] and q[1] == n[1][0]:
            matches.append(n)
    if len(matches) == 0:
        print("nobody")
    elif len(matches) == 1:
        print(" ".join(matches[0]))
    else:
        print("ambiguous")
