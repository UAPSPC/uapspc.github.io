#include <bits/stdc++.h>

using namespace std;

int main() {
  int n, q;
  cin >> n >> q;

  // init_to_name[init] will be the vector of full names
  // of people whose initials are the same as the string "init"
  map<string, vector<string>> init_to_name;

  for (int i = 0; i < n; ++i) {
    string firstname, lastname;
    cin >> firstname >> lastname;

    // get the initials of this person
    string init = {firstname[0], lastname[0]};

    // add their full name to the list of people with these initials
    init_to_name[init].push_back(firstname + " " + lastname);
  }

  for (int i = 0; i < q; ++i) {
    string init;
    cin >> init;

    // if the initials "init" were not recorded before,
    // then accessing init_to_name[init] will create a vector
    // of length 0 before the method .size() is called
    switch (init_to_name[init].size()) {
      case 0:
        cout << "nobody" << endl;
        break;
      case 1:
        cout << init_to_name[init][0] << endl;
        break;
      default:
        cout << "ambiguous" << endl;
        break;
    }
  }

  return 0;
}