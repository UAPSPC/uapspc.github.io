x1, x2, y1, y2 = map(int, input().split())
xs, ys, xr, yr = map(int, input().split())

# want to check cross product between the heading of the ray
# and each corner, so translate start to 0,0 so that the cross
# product of r and each corner tells us where the intersection is

x1 -= xs
x2 -= xs
y1 -= ys
y2 -= ys
xr -= xs
yr -= ys
xs, ys = 0, 0

# get the direction xr, yr is in about the origin (start)
# then check cross product of found corner against xr, yr
response = None
if(xr >= 0 and yr >= 0):
    # top right (x2, y2)
    c = xr*y2 - yr*x2
    if(c == 0): response = "top-right"
    elif(c > 0): response = "right"
    else: response = "top"
elif(xr >= 0 and yr <= 0):
    # bot right (x2, y1)
    c = xr*y1 - yr*x2
    if(c == 0): response = "bottom-right"
    elif(c > 0): response = "bottom"
    else: response = "right"
elif(xr <= 0 and yr <= 0):
    # bot left (x1, y1)
    c = xr*y1 - yr*x1
    if(c == 0): response = "bottom-left"
    elif(c > 0): response = "left"
    else: response = "bottom"
elif(xr <= 0 and yr >= 0):
    # top left (x1, y2)
    c = xr*y2 - yr*x1
    if(c == 0): response = "top-left"
    elif(c > 0): response = "top"
    else: response = "left"

print(response)