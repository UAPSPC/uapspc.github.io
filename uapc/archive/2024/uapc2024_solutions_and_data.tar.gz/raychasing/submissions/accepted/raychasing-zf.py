#!/bin/python3

X1, X2, Y1, Y2 = map(int, input().split())
XS, YS, XR, YR = map(int, input().split())

# translate so the ray starts at (0,0)
X1 -= XS
X2 -= XS
XR -= XS

Y1 -= YS
Y2 -= YS
YR -= YS

# assumes XR, YR >= 0
def solve(X2, Y2, XR, YR):
  sgn = X2*YR - Y2*XR
  if sgn > 0: return "top"
  elif sgn < 0: return "right"
  else: return "top-right"

# assumes XR >= 0
# reduces to the version where we can assume YR >= 0
# by flipping top/bottom if necessary
def make_up(X2, Y1, Y2, XR, YR):
  if YR < 0: return solve(X2, -Y1, XR, -YR).replace("top", "bottom")
  else: return solve(X2, Y2, XR, YR)

# reduces to the version where we can assume XR >= 0
# by flipping left/right if necessary
def make_right(X1, X2, Y1, Y2, XR, YR):
  if XR < 0: return make_up(-X1, Y1, Y2, -XR, YR).replace("right", "left")
  else: return make_up(X2, Y1, Y2, XR, YR)

print(make_right(X1, X2, Y1, Y2, XR, YR))

