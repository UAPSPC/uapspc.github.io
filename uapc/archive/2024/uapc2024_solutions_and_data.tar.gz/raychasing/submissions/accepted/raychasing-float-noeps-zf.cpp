/*
  Dangerous submission, uses only float (no double)
  and does not do epsilon checks. But it still passes, which is ok.

  Better to use the "double" type and check x + EPS > 0 rather than x >= 0
  for some small EPS like 1e-6.
*/

#include <bits/stdc++.h>

using namespace std;

using T = float;

const T EPS = 0.0;

/*
  p.cross(q)
  Consider the shortest from p to q about the origin
  If this is a CCW turn, p.cross(q) > 0
  If this is a CW turn, p.cross(q) < 0
  If p and q are colinear with the origin, p.cross(q) == 0
*/

struct point {
  T x, y;
  T cross(point q) { return x*q.y - y*q.x; }
  point operator-(point q) { return {x-q.x, y-q.y}; }
};

int main() {
  // bl, ur mean bottom-left and upper-right corners of the box
  point bl, ur, s, r;
  
  cin >> bl.x >> ur.x >> bl.y >> ur.y;
  cin >> s.x >> s.y >> r.x >> r.y;


  // translate so the ray originates from (0,0)
  bl = bl-s;
  ur = ur-s;
  r = r-s;

  // the other two corners of the box
  point ul = {bl.x, ur.y}, br = {ur.x, bl.y};


  auto check = [&](point corner, string first, string second, string both) {
    T c = r.cross(corner);
    if (c == 0) return both;
    else if (c > 0) return first;
    else return second;
  };

  string ans;

  if (r.y >= -EPS && r.x >= -EPS)
    ans = check(ur, "right", "top", "top-right");
  else if (r.y >= -EPS && r.x < -EPS)
    ans = check(ul, "top", "left", "top-left");
  else if (r.y < -EPS && r.x < -EPS)
    ans = check(bl, "left", "bottom", "bottom-left");
  else
    ans = check(br, "bottom", "right", "bottom-right");

  cout << ans << endl;
}
