#include <bits/stdc++.h>

using namespace std;

using ll = long long;

int main() {
  int N;
  cin >> N;

  ll ans = 1, potatoes = 1, gravy = 1;

  for (int i = 0; i < N; ++i) {
    char food;
    ll num;
    cin >> food >> num;
    if (food == 'P') {
      if (potatoes < gravy && potatoes + num >= gravy) ++ans;
      potatoes += num;
    }
    else {
      ans += min(num, max(0ll, potatoes - gravy));
      gravy += num;
    }
  }

  cout << ans << endl;

  return 0;
}