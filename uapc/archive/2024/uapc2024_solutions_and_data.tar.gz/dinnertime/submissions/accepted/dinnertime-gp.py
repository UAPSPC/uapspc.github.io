n = int(input())

g, p, tot = 0, 0, 1

for _ in range(n):
    tok, k = input().split()
    k = int(k)

    if(tok == 'P'):
        # the potatoes passed the person with the gravy
        if(p < g and p+k >= g): tot += 1
        p += k
    elif(tok == 'G'):
        # the gravy passed the person with the potatoes
        if(g < p and g+k >= p): tot += p-g
        # the gravy did not pass the person with the potatoes
        elif(g < p): tot += k
        g += k

print(tot)