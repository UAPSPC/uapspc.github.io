#!/bin/python3

N = int(input())

# ans - number with both (person 1 always gets both)
# potatoes, grave is the current position of each dish
ans, potatoes, gravy = 1, 1, 1

for _ in range(N):
  food, num = input().split()
  num = int(num)

  if food == "P":
    # if the person with the gravy receives the potatoes as they are passed,
    # record this
    if potatoes < gravy and potatoes + num >= gravy: ans += 1;

    # new position of the potatoes
    potatoes += num

  else:
    # if potatoes >= gravy, then the next min(num, potatoes-gravy) people
    # will get gravy on their potatoes
    ans += min(num, max(0, potatoes - gravy))

    # new position of the gravy
    gravy += num

print(ans)