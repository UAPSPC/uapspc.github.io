#include <bits/stdc++.h>
using namespace std;

int main(){
    int n; cin >> n;

    bool k = 0, p = 0, w = 0;
    while(n--){
        string s; cin >> s;
        if(s == "keys") k = 1;
        if(s == "phone") p = 1;
        if(s == "wallet") w = 1;
    }

    if(!k) cout << "keys" << endl;
    if(!p) cout << "phone" << endl;
    if(!w) cout << "wallet" << endl;
    if(k && p && w) cout << "ready" << endl;

    return 0;
}