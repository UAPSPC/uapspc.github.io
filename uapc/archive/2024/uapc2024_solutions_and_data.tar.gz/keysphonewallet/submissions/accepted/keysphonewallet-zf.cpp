#include <bits/stdc++.h>

using namespace std;

int main() {
  set<string> items = {"keys", "phone", "wallet"};
  
  int N;
  cin >> N;
  
  for (int i = 0; i < N; ++i) {
    string x;
    cin >> x;
    if (items.find(x) != items.end()) items.erase(x);
  }

  if (items.size() == 0) cout << "ready" << endl;
  else for (string x : items) cout << x << endl;

  return 0;
}