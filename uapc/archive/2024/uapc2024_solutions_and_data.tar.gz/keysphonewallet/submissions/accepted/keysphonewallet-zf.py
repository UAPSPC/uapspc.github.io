#!/bin/python3

items = {"keys", "phone", "wallet"}

N = int(input())
taken = [input() for _ in range(N)]

# this will remove all of the strings in "taken" from the set "items"
items.difference_update(taken)

if items: print(*sorted(items), sep="\n")
else: print("ready")
