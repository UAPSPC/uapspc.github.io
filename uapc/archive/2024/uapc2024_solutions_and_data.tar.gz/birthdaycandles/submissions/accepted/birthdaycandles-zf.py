#!/bin/python3

import sys

N, H, C = map(int, input().split())

# read each guest and sort their candles
guests = [sorted(map(int, input().split())) for i in range(N)]

tot = 0

# try to blow out the first candles from each guest, then the second candles, etc.
for j in range(H):
  # for each of the j'th candles brought by the guests in sorted order
  for x in sorted([guests[i][j] for i in range(N)]):
    # if we can still blow it out, then do so
    if x <= C:
      tot += 1
      C -= x
    # otherwise, we must stop here: print the answer and quit
    else:
      print(tot)
      sys.exit(0)

print(tot)