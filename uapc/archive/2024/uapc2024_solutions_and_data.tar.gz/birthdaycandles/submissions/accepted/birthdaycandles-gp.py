#!/bin/python3

n, h, c = map(int, input().split())

p = [sorted([int(x) for x in input().split()], reverse=True) for _ in range(n)]
layers = [sorted([p[i][j] for i in range(n)], reverse=True) for j in range(h)]

tot = 0
while(c >= 0 and len(layers) > 0):
    c -= layers[-1].pop()
    if(len(layers[-1]) == 0): layers.pop()
    if(c >= 0): tot += 1

print(tot)