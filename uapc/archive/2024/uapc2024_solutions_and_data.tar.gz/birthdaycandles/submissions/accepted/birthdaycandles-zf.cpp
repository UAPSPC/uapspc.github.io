#include <bits/stdc++.h>

using namespace std;

int main() {
  int N, H, C;
  cin >> N >> H >> C;

  vector<vector<int>> guests(N, vector<int>(H));

  for (auto& v : guests) {
    for (auto& x : v) cin >> x;
    sort(v.begin(), v.end());
  }

  int tot = 0;
  for (int j = 0; j < H; ++j) {
    vector<int> column(N);
    
    for (int i = 0; i < N; ++i) column[i] = guests[i][j];
    sort(column.begin(), column.end());

    for (int x : column) {
      if (x <= C) {
        C -= x;
        ++tot;
      }
      else {
        cout << tot << endl;
        return 0;
      }
    }
  }

  cout << tot << endl;
  return 0;
}