#!/bin/python3

N, K = map(int, input().split())

move = 0

for i in range(N):
  # get the set of unique pencil crayons in box i
  box = set(input().split())
  # move all duplicates out
  move += K-len(box)

print(move)
