/*
  A simpler implementation that only uses arrays, no sets.
*/

#include <bits/stdc++.h>

using namespace std;

int main() {
  int N, K;
  cin >> N >> K;

  int ans = 0;

  for (int i = 0; i < N; ++i) {
    // the crayons in this box
    vector<string> box;

    for (int j = 0; j < K; ++j) {
      string colour;
      cin >> colour;

      // check if this colour has previously appeared
      // in this box
      bool seen = false;
      for (string c : box)
        if (c == colour)
          seen = true;
      
      // if so, we have to move this crayon
      if (seen) ++ans;

      box.push_back(colour);
    }
  }

  cout << ans << endl;
}