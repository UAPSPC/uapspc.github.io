#!/bin/python3

n, k = map(int, input().split())

tot = 0
for _ in range(n):
    box = set()
    for p in input().split():
        box.add(p)
    tot += k-len(box)

print(tot)
        