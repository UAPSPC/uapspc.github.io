#include <bits/stdc++.h>
using namespace std;

#define rep(i, a, b) for(int i = a; i < (b); ++i)
#define all(x) begin(x), end(x)
#define sz(x) (int)(x).size()
typedef long long ll;
typedef long double ld;
typedef pair<int, int> pii;
typedef vector<int> vi;
#define pb push_back
#define mp make_pair

#define MAXN 501

vi adj[MAXN];
int par[MAXN];
int c[MAXN];
int x[MAXN];
int n;
ld memo[2][MAXN][MAXN];


int main() {
	cin.tie(0)->sync_with_stdio(0);
	cin.exceptions(cin.failbit);

    cin >> n;
    par[0] = -2;
    rep(i, 0, n-1) {
        int u, v;
        cin >> u >> v;
        u--; v--;
        adj[u].pb(v);
        par[v] = u;
    }
    rep(i, 0, n) cin >> x[i] >> c[i];

    for (int pos = n-1; pos >= 0; pos--) {
        memo[0][pos][0] = 1; // at start, always have 0
        int ind = 0;
        rep(local, 0, x[pos]) {
            ind = ind^1;
            rep(amt, 0, MAXN) memo[ind][pos][amt] = 0;
            for (int amt = 0; amt <= c[pos]; amt++) {
                // with 50% probability we are present
                if (amt < c[pos]) {
                    memo[ind][pos][amt+1] += memo[ind^1][pos][amt]/2;
                }
                else memo[ind][pos][amt] += memo[ind^1][pos][amt]/2;
                // with 50% probability we are gone
                memo[ind][pos][amt] += memo[ind^1][pos][amt]/2;
            }
        }

        for (int nxt : adj[pos]) {
            ind = ind^1;
            rep(amt, 0, MAXN) memo[ind][pos][amt] = 0;
            rep(amt, 0, c[nxt]+1) rep(amt2, 0, c[pos]+1) {
                // probability we hit amt at nxt and amt2 at pos
                int newamt = min(amt+amt2, c[pos]);
                memo[ind][pos][newamt] += memo[ind^1][pos][amt2] * memo[0][nxt][amt];
            }
        }

        // now put at 0
        if (ind != 0) {
            rep(amt, 0, c[pos]+1) memo[0][pos][amt] = memo[1][pos][amt];
        }
    }
    ld out = 0;
    rep(amt, 0, c[0]+1) {
        out += amt * memo[0][0][amt];
    }
    cout << fixed << setprecision(20) << out << endl;
}