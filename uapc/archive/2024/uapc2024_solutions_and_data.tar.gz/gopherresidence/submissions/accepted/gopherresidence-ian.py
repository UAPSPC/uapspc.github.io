#!/bin/python3

from collections import defaultdict

def huh():
    return 0

def main():
    MAXAMT = 101
    n = int(input())
    adj = dict()
    for i in range(n):
        adj[i] = []
    for _ in range(n-1):
        u, v = map(int, input().split())
        u -= 1
        v -= 1
        adj[u].append(v)
    x = [0 for _ in range(n)]
    c = [0 for _ in range(n)]
    for i in range(n):
        x[i], c[i] = map(int, input().split())
    
    memo = defaultdict(huh)
    for pos in range(n-1, -1, -1):
        memo[(0, pos, 0)] = 1
        ind = 0
        for local in range(x[pos]):
            ind = ind^1
            for amt in range(MAXAMT):
                memo[(ind, pos, amt)] = 0
            for amt in range(c[pos]+1):
                if amt < c[pos]:
                    memo[(ind, pos, amt+1)] += memo[(ind^1, pos, amt)] * 0.5
                else:
                    memo[(ind, pos, amt)] += memo[(ind^1, pos, amt)] * 0.5
                memo[(ind, pos, amt)] += memo[(ind^1, pos, amt)] * 0.5
        
        for nxt in adj[pos]:
            ind = ind^1
            for amt in range(MAXAMT):
                memo[(ind, pos, amt)] = 0
            for amt in range(c[nxt]+1):
                for amt2 in range(c[pos]+1):
                    newamt = min(amt+amt2, c[pos])
                    memo[(ind, pos, newamt)] += memo[(ind^1, pos, amt2)] * memo[(0, nxt, amt)]
        if ind != 0:
            for amt in range(c[pos]+1):
                memo[(0, pos, amt)] = memo[(1, pos, amt)]
    out = 0
    for amt in range(c[0]+1):
        out += amt * memo[(0, 0, amt)]
    print("%.20f" % out)



main()