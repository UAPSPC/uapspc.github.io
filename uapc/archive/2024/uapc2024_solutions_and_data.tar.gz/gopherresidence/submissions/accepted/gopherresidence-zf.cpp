/*
  Idea: If we knew exactly how many squirrels were at each node after some went out,
  the optimal solution is computed greedily in a bottom-up fashion in the tree:
  at each node v we clamp the current squirrel count in that subtree to c[v] but
  only after subtrees have been processed accordingly.

  So for the main problem, we compute at each node the probability distribution over
  squirrel counts in that subtree if they are clamped to be feasible. To combine
  the results for the children of a node to the vector for the node itself,
  just combine them one pair at a time. See "combine" below for details.

  Running time: O(N*M^2) where M is the maximum among the given capacities and squirrel
  counts across the nodes.

  Advanced analysis: The running time is also O(S^2) where S is the total number of squirrels
  in the tree. This can be faster than O(N*M^2) in some cases. Note, this would hold
  even if the capacities of subtrees were pretty high and even if the number of nodes
  was bigger. Ping Zac if you want to learn more details behind this analysis.
*/

#include <bits/stdc++.h>

using namespace std;

using vd = vector<double>;
using ul = unsigned long;

vector<vector<int>> tree;
vector<ul> x, c;

// a[] and b[] give probability distributions over numbers
// of squirrels, returns the probability distribution over the
// total number of squirrels if we sample some squirrels according 
// to a[] and then some according to b[], and clamp the number sampled to k
vd combine(const vd& a, const vd& b, ul k) {
  vd res(min(k+1, a.size() + b.size() - 1), 0.0);

  for (ul i = 0; i < a.size(); ++i)
    for (ul j = 0; j < b.size(); ++j)
      res[min(k, i+j)] += a[i]*b[j];
  
  return res;
}

// returns a vector pr where pr[i] is the probability exactly
// i squirrels remain in subtree i afterward
vd dfs(int v) {
  // Compute distribution over squirrel counts at this node,
  // clamped to c[v]. Running time, O(M^2) (see M in the comments above)
  // since each call to "combine" runs in O(M) time as one vector
  // has size only 2
  vd pr = {1.0};
  for (int i = 0; i < x[v]; ++i) pr = combine(pr, {0.5, 0.5}, c[v]);

  // running time per iteration is O(M^2)
  // total number of iterations across all recursive calls is N-1
  // since there are N-1 edges in the tree
  for (auto w : tree[v]) pr = combine(pr, dfs(w), c[v]);

  return pr;
}

int main() {
  int n;
  cin >> n;

  tree.resize(n);
  for (int i = 0, u, v; i < n-1; ++i) {
    cin >> u >> v;
    tree[u-1].push_back(v-1);
  }

  x = c = vector<ul>(n);
  for (int i = 0; i < n; ++i) cin >> x[i] >> c[i];

  vd pr = dfs(0);

  double ans = 0.0;
  for (int i = 0; i < pr.size(); ++i) ans += i*pr[i];

  cout << fixed << setprecision(20) << ans << endl;

  return 0;
}
