#!/bin/python3

import sys

sys.setrecursionlimit(2*10**5)

n, m = map(int, input().split())

g =[[] for _ in range(n)]
colour = [4]*n
for _ in range(m):
  u, v = map(int, input().split())
  g[u-1].append(v-1)
  g[v-1].append(u-1)

def dfs(v):
  if colour[v] == 4:
    nbr_colours = [colour[w] for w in g[v]]
    colour[v] = min(c for c in range(1, 4) if c not in nbr_colours)
    for w in g[v]: dfs(w)

for v in range(n): dfs(v)

print(*colour)
