import sys
sys.setrecursionlimit(200000)
n, m = map(int, input().split())
adj = [[] for _ in range(n)]
for i in range(m):
    a, b = map(int, input().split())
    a -= 1
    b -= 1
    adj[a].append(b)
    adj[b].append(a)
c = [0]*n
def dfs(i):
    if c[i] > 0:
        return
    avail = [True, True, True, True]
    for v in adj[i]:
        avail[c[v]] = False
    for j in range(1,4):
        if avail[j]:
            c[i] = j
            break
    for v in adj[i]:
        dfs(v)

for i in range(n):
    dfs(i)
print(" ".join(map(str, c)))
