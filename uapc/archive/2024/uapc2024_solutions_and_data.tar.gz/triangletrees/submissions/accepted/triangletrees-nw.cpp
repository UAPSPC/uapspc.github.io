#include<bits/stdc++.h>
using namespace std;
int main() {
    cin.tie(0);
    ios::sync_with_stdio(0);
    int n, m;
    cin >> n >> m;
    vector<vector<int>> adj(n);
    for (int i = 0; i < m; i++) {
        int a, b;
        cin >> a >> b;
        a--; b--;
        adj[a].push_back(b);
        adj[b].push_back(a);
    }
    vector<int> c(n, 0);
    vector<int> q;
    for (int i = 0; i < n; i++)
        q.push_back(i);
    while (!q.empty()) {
        int i = q.back();
        q.pop_back();
        if (c[i]) continue;
        bool used[4] = {0};
        for (int j : adj[i]) {
            used[c[j]] = 1;
            if (!c[j]) q.push_back(j);
        }
        for (int j = 1; j < 4; j++)
            if (!used[j]) {
                c[i] = j;
                break;
            }
        assert(c[i]);
    }
    for (int i = 0; i < n; i++)
        for (int j : adj[i])
            assert(c[i] != c[j]);

    for (int i = 0; i < n; i++)
        cout << c[i] << " ";
    cout << endl;
}
