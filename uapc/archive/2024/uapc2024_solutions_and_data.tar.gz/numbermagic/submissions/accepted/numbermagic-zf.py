#!/bin/python3

from collections import deque

MDIST = 32
CUTOFF = 25
RCUTOFF = MDIST-CUTOFF

def getones(k):
  m, ones = k, 0
  while m:
    m, ones = m//10, ones*10 + 1
  return ones

MX = 2**63

def enqueue(k, pre, d, q, limit):
  if k not in d and k < MX:
    d[k] = d[pre]+1
    if d[k] < limit: q.append(k)

N, Q = map(int, input().split())

dist = {N:0}
q = deque([N])
while q:
  k = q.popleft()
  enqueue(k//2, k, dist, q, CUTOFF)
  enqueue(k+getones(k), k, dist, q, CUTOFF)

for _ in range(Q):
  M = int(input())
  rdist = {M:0}
  rq = deque([M])
  msg = "NO"

  while rq:
    k = rq.popleft()
    enqueue(2*k, k, rdist, rq, RCUTOFF)
    enqueue(2*k+1, k, rdist, rq, RCUTOFF)

    ones = getones(k)
    for __ in range(2):
      nk = k-ones
      if nk > 0 and nk+getones(nk) == k:
        enqueue(nk, k, rdist, rq, RCUTOFF)
      ones //= 10
  
  for x in rdist:
    if x in dist:
      msg = "YES"

  print(msg)
