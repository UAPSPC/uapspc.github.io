/*
  Recursive with a mild optimization in the reverse search.
  Doesn't seem to help a lot.
*/

#include <bits/stdc++.h>

using namespace std;

using ll = long long;

const int MDIST = 32;
const int CUTOFF = 23;
const int RCUTOFF = MDIST - CUTOFF;

ll N, Q, M;
unordered_set<ll> seen;

ll getones(ll k) {
  ll m = k, ones = 0;
  while (m) {
    m /= 10;
    ones = ones*10 + 1;
  }
  return ones;  
}

void generate_forward(ll k, int cur_dist) {
  seen.insert(k);

  if (cur_dist) {
    generate_forward(k/2, cur_dist-1);
    generate_forward(k+getones(k), cur_dist-1);
  }
}

bool generate_reverse(ll k, int cur_dist) {
  // guards against overflow in a recursive call
  if (k <= 0) return false;

  if (seen.find(k) != seen.end()) return true;

  if (cur_dist) {
    if (generate_reverse(2*k, cur_dist-1)) return true;
    if (generate_reverse(2*k+1, cur_dist-1)) return true;

    ll ones = getones(k);
    for (int i = 0; i < 2; ++i) {
      ll nk = k-ones;
      if (nk > 0 && nk+getones(nk) == k && generate_reverse(nk, cur_dist-1)) return true;
      ones /= 10;
    }
  }
  return false;
}

int main() {
  cin >> N >> Q;
  generate_forward(N, CUTOFF);

  while (Q--) {
    cin >> M;
    cout << (generate_reverse(M, RCUTOFF) ? "YES" : "NO") << endl;
  }

  return 0;
}