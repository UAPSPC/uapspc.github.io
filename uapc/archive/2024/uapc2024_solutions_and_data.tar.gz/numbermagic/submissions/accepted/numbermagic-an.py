import math

# Constants
MAX = 32
N = 23

# Result array
res = [[0 for _ in range(1 << (N + 1))] for _ in range(2)]

def addion(origin):
    """
    Custom addition function that adds 1 to the origin and then
    increments it by 10^x for each power of 10 it exceeds.
    """
    tmp = origin + 1
    th = 10
    while True:
        if th > origin:
            break
        tmp += th
        th *= 10
    return tmp

def main():
    # Inputs for n and q
    n, q = map(int, input().split())

    # Map to store results with custom keys
    mapped_res = {}
    mapped_res[n] = (0, 0)
    res[0][0] = n
    
    # Populate the result array and mapped_res
    for i in range(1, N + 1):
        for x in range(1 << (i - 1)):
            origin = res[(i - 1) % 2][x]
            tmp = origin // 2
            res[i % 2][x * 2] = tmp
            if tmp not in mapped_res:
                mapped_res[tmp] = (x * 2, i)
            tmp = addion(origin)
            res[i % 2][x * 2 + 1] = tmp
            if tmp not in mapped_res:
                mapped_res[tmp] = (x * 2 + 1, i)

    # Process queries
    for _ in range(q):
        m = int(input())
        res[0][0] = m
        if m in mapped_res:
            print("YES")
            continue
        
        found = False
        mx = 1
        for i in range(1, MAX - N + 1):
            for x in range(mx):
                origin = res[(i - 1) % 2][x]
                if origin == -1:
                    for t in range(3):
                        res[i % 2][x * 3 + t] = -1
                    continue
                for mult_factor, offset in ((2, 0), (2, 1), (-1, 2)):
                    if mult_factor != -1:
                        tmp = origin * mult_factor + offset
                    else:
                        tmp = origin - 1
                        th = 10
                        while True:
                            if th > origin or tmp < th:
                                break
                            tmp -= th
                            th *= 10
                        if addion(tmp) != origin:
                            res[i % 2][x * 3 + offset] = -1
                            continue
                    res[i % 2][x * 3 + offset] = tmp
                    if tmp in mapped_res and mapped_res[tmp][1] + i <= MAX:
                        found = True
                        break
                if found:
                    break
            mx *= 3
            if found:
                break
        print("YES" if found else "NO")

if __name__ == "__main__":
    main()
