/*
  No optimizations, the full forward and reverse search that might expand
  a node multiple times in different branches of recursion.
*/

#include <bits/stdc++.h>

using namespace std;

using ll = long long;

const int MDIST = 32;
const int CUTOFF = 23;
const int RCUTOFF = MDIST - CUTOFF;

ll N, Q, M;
unordered_set<ll> seen;
bool found;

ll getones(ll k) {
  ll m = k, ones = 0;
  while (m) {
    m /= 10;
    ones = ones*10 + 1;
  }
  return ones;  
}

void generate_forward(ll k, int cur_dist) {
  seen.insert(k);

  if (cur_dist) {
    generate_forward(k/2, cur_dist-1);
    generate_forward(k+getones(k), cur_dist-1);
  }
}

void generate_reverse(ll k, int cur_dist) {
  // guards against overflow in a recursive call
  if (k <= 0) return;

  if (seen.find(k) != seen.end()) found = true;

  if (cur_dist) {
    generate_reverse(2*k, cur_dist-1);
    generate_reverse(2*k+1, cur_dist-1);

    ll ones = getones(k);
    for (int i = 0; i < 2; ++i) {
      ll nk = k-ones;
      if (nk > 0 && nk+getones(nk) == k) generate_reverse(nk, cur_dist-1);
      ones /= 10;
    }
  }
}

int main() {
  cin >> N >> Q;
  generate_forward(N, CUTOFF);

  while (Q--) {
    cin >> M;
    found = false;
    generate_reverse(M, RCUTOFF);
    cout << (found ? "YES" : "NO") << endl;
  }

  return 0;
}