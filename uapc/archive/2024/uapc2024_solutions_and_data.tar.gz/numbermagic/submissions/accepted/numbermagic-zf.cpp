#include <bits/stdc++.h>

using namespace std;

using ll = long long;

const int MDIST = 32;
const int CUTOFF = 25;
const int RCUTOFF = MDIST - CUTOFF;

// return the integer with all 1s matching the number of digits of k
// e.g. k = 20140 would return 11111
ll getones(ll k) {
  ll m = k, ones = 0;
  while (m) {
    m /= 10;
    ones = ones*10 + 1;
  }
  return ones;  
}

// if k was not reached before
void enqueue(ll k, ll pre, unordered_map<ll, int>& dist, queue<ll>& q, int limit) {
  if (dist.find(k) == dist.end()) {
    dist[k] = dist[pre]+1;
    if (dist[k] < limit) q.push(k);
  }
}

int main() {
  ll N, Q;
  cin >> N >> Q;

  unordered_map<ll, int> dist;

  dist[N] = 0;
  queue<ll> q;
  q.push(N);
  while (q.size() > 0) {
    ll k = q.front();
    q.pop();

    enqueue(k/2, k, dist, q, CUTOFF);
    enqueue(k+getones(k), k, dist, q, CUTOFF);
  }

  for (int iter = 0; iter < Q; ++iter) {
    unordered_map<ll, int> rdist;
    queue<ll> rq;

    ll M;
    cin >> M;
    rdist[M] = 0;
    rq.push(M);

    while (rq.size() > 0) {
      ll k = rq.front();
      // if (dist.find(k) != dist.end()) {
      //   cout << "YES" << endl;
      //   break;
      // }
      rq.pop();

      // check for overflow, if so the number is too big to be used in a solution
      if (2*k+1 > k) {
        enqueue(2*k, k, rdist, rq, RCUTOFF);        
        enqueue(2*k+1, k, rdist, rq, RCUTOFF);
      }
      ll ones = getones(k);
      for (int i = 0; i < 2; ++i) {
        ll nk = k-ones;
        if (nk > 0 && nk+getones(nk) == k) enqueue(nk, k, rdist, rq, RCUTOFF);
        ones /= 10;
      }
    }
    bool found = false;
    for (auto [l, d] : rdist)
      if (dist.find(l) != dist.end()) found = true;
    cout << (found ? "YES" : "NO") << endl;
    // if (rq.size() == 0) cout << "NO" << endl;
  }


  return 0;
}