#include <cstdio>
#include <cmath>
#include <unordered_map>
#include <chrono>
#include <random>

using ULL = unsigned long long;

#define MAX 32
#define N 23

ULL res[2][1 << (N + 1)];

static inline ULL addion(ULL origin) {
    ULL tmp = origin + 1;
    ULL th = 10;
    for (;;) {
        if (th > origin) break;
        tmp += th;
        th *= 10;
    }
    return tmp;
}

void print_path(ULL n, ULL m, ULL forward, int forward_cnt, ULL backward, int backward_cnt) {
    static int stack[64];
    const static int size = 1048576;
    static char buf[size];
    int cnt = 0;
    int idx = 0;
    cnt += snprintf(&buf[cnt], size - cnt, "%llu %llu %d %llu %d\n", n, forward, forward_cnt, backward, backward_cnt);
    for (int i = 0; i < forward_cnt; ++i) {
        stack[i] = forward % 2;
        forward /= 2;
    }
    for (int i = forward_cnt - 1; i >= 0; --i) {
        idx++;
        if (stack[i]) {
            n = addion(n);
            cnt += snprintf(&buf[cnt], size - cnt, "%2d: + 1 = %llu\n", idx, n);
        } else {
            n /= 2;
            cnt += snprintf(&buf[cnt], size - cnt, "%2d: / 2 = %llu\n", idx, n);
        }
    }
    cnt += snprintf(&buf[cnt], size - cnt, "======\n");
    for (int i = 0; i < backward_cnt; ++i) {
        idx++;
        if (backward % 3 == 2) {
            n = addion(n);
            cnt += snprintf(&buf[cnt], size - cnt, "%2d: + 1 = %llu\n", idx, n);
        } else {
            n /= 2;
            cnt += snprintf(&buf[cnt], size - cnt, "%2d: / 2 = %llu\n", idx, n);
        }
        backward /= 3;
    }
    if (n != m) {
        printf("%s", buf);
        fflush(stdout);
        abort();
    }
}


int main() {
    // std::random_device rd;
    // std::uniform_int_distribution<ULL> dist(0, 1000000ULL);
    // for(;;) {
    // auto start = std::chrono::steady_clock::now();
    ULL n, q, m;

    scanf("%llu%llu", &n, &q);

    std::unordered_map<ULL, std::pair<ULL, int>> mapped_res;
    mapped_res.reserve(1 << (N + 1));
    res[0][0] = n;
    mapped_res[n] = std::make_pair<ULL, int>(0, 0);
    for (int i = 1; i <= N; ++i) {
        for (ULL x = 0; x < (1ULL << (i - 1)); ++x) {
            ULL origin = res[(i - 1) % 2][x];
            ULL tmp = origin / 2;
            res[i % 2][x * 2] = tmp;
            if (!mapped_res.count(tmp)) mapped_res[tmp] = std::make_pair<ULL, int>(x * 2, std::move(i));
            tmp = addion(origin);
            res[i % 2][x * 2 + 1] = tmp;
            if (!mapped_res.count(tmp)) mapped_res[tmp] = std::make_pair<ULL, int>(x * 2 + 1, std::move(i));
        }
    }
    // int res_cnt[2] = {};
    while (q--) {
        // m = dist(rd);
        scanf("%llu", &m);
        res[0][0] = m;
        auto it = mapped_res.find(m);
        if (it != mapped_res.end()) {
            printf("YES\n");
            continue;
        }
        bool found = false;
        ULL mx = 1;
        for (int i = 1; i <= MAX - N; ++i) {
            for (ULL x = 0; x < mx; ++x) {
                ULL origin = res[(i - 1) % 2][x];
                if (origin == (ULL)-1) {
                    for (ULL t = 0; t < 3; ++t) {
                        res[i % 2][x * 3 + t] = -1;
                    }
                    continue;
                }
                ULL tmp = origin * 2;
                res[i % 2][x * 3] = tmp;
                auto it = mapped_res.find(tmp);
                if (it != mapped_res.end() && it->second.second + i <= MAX) {
                    // printf("match %llu\n", tmp);
                    // print_path(n, m, it->second.first, it->second.second, x * 3, i);
                    found = true;
                    break;
                }
                tmp = origin * 2 + 1;
                res[i % 2][x * 3 + 1] = tmp;
                it = mapped_res.find(tmp);
                if (it != mapped_res.end() && it->second.second + i <= MAX) {
                    // printf("match %llu\n", tmp);
                    // print_path(n, m, it->second.first, it->second.second, x * 3 + 1, i);
                    found = true;
                    break;
                }
                if (origin == 0) {
                    continue;
                }
                tmp = origin - 1;
                ULL th = 10;
                for (;;) {
                    if (th > origin) break;
                    if (tmp < th) break;
                    tmp -= th;
                    th *= 10;
                }
                if (addion(tmp) != origin) {
                    // printf("try failed, from %llu to %llu\n", origin, tmp);
                    res[i % 2][x * 3 + 2] = -1;
                    continue;
                }
                res[i % 2][x * 3 + 2] = tmp;
                it = mapped_res.find(tmp);
                if (it != mapped_res.end() && it->second.second + i <= MAX) {
                    // printf("match %llu\n", tmp);
                    // print_path(n, m, it->second.first, it->second.second, x * 3 + 2, i);
                    found = true;
                    break;
                }
            }
            mx *= 3ULL;
            if (found) break;
        }
        // res_cnt[found]++;
        printf(found ? "YES\n" : "NO\n");
    }
    
}