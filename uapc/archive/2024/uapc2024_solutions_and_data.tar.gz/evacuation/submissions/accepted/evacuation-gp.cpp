#include <bits/stdc++.h>
using namespace std;

#define pb push_back
#define rep(i, a, b) for(int i = a; i < (b); ++i)
#define all(x) begin(x), end(x)
#define sz(x) (int)(x).size()
typedef long long ll;
typedef pair<int, int> pii;
typedef vector<int> vi;

int main(){
    cin.tie(0)->sync_with_stdio(0);
	cin.exceptions(cin.failbit);

    int n, m, k; cin >> n >> m >> k;
    int h, e; cin >> h >> e;

    vector<vector<pii>> AL(n+1);

    rep(i, 0, m){
        int u, v, w; cin >> u >> v >> w;
        AL[u].pb({v, w});
        AL[v].pb({u, w});
    }

    unordered_map<int, int> edges;
    unordered_map<int, int> restriction;

    int u, v; cin >> v;
    restriction[v] = 0;
    rep(i, 0, k-1){
        u = v;
        cin >> v;
        
        edges[u] = v;
        for(auto [x, w]: AL[u])
            if(x == v)
                restriction[v] = restriction[u] + w;
    }

    priority_queue<pii, vector<pii>, greater<pii>> pq;
    unordered_set<int> seen;

    pq.emplace(0, h);
    while(!pq.empty()){
        auto [t, u] = pq.top(); pq.pop();

        if(seen.count(u)) continue;
        if(u == e){
            cout << t << endl;
            return 0;
        }
        seen.insert(u);

        for(auto [v, w]:AL[u]){
            // If the tornado goes over the bridge (u, v) and arrives at u before we reach v we cannot take the bridge
            if(edges.count(u) && edges[u] == v && restriction[u] < t+w) continue;
            // If the tornado goes over the bridge (v, u) and arrives at v before we reach v we cannot take the bridge
            if(edges.count(v) && edges[v] == u && restriction[v] < t+w) continue;

            if(!seen.count(v)) pq.emplace(t+w, v);
        }
    }

    cout << -1 << endl;

    return 0;
}