#!/bin/python3

import heapq

n, m, q = map(int, input().split())
h, e = map(int, input().split())

# destroyed[(u,v)] will be the time that bridge (u,v) is destroyed,
# 10**9 if it is never destroyed
destroyed = {}

# time[(u,v)] is the time to traverse bridge u
time = {}

# g[u] is the list of neighbours of v
g = [[] for _ in range(n+1)]

for _ in range(m):
  u, v, t = map(int, input().split())

  destroyed[(u,v)] = destroyed[(v,u)] = 10**9
  time[(u,v)] = time[(v,u)] = t

  g[u].append(v)
  g[v].append(u)

path = list(map(int, input().split()))

# simulate the tornados path and record when each bridge is destroyed
t = 0
for i in range(1, len(path)):
  bridge, rev = (path[i-1], path[i]), (path[i], path[i-1])
  destroyed[bridge] = destroyed[rev] = t
  t += time[bridge]

# reached[v] is the length of the shortest path to v that is safe
reached = {}

pq = [(0, h)]

while pq:
  t, u = heapq.heappop(pq)
  if u in reached: continue
  reached[u] = t
  for v in g[u]:
    nt = t + time[(u,v)]
    if nt <= destroyed[(u,v)]: heapq.heappush(pq, (nt, v))

print(-1 if e not in reached else reached[e])
