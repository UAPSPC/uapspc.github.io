#include <bits/stdc++.h>
using namespace std;

#define pb push_back
#define rep(i, a, b) for(int i = a; i < (b); ++i)
#define all(x) begin(x), end(x)
#define sz(x) (int)(x).size()
typedef long long ll;
typedef pair<int, int> pii;
typedef vector<int> vi;

// dp[i][j] = is there a valid way to deconstruct s1[0,...,i] in to s2[0,...,j]
//      the transition must check every every possible power string that can end at i, j
int dp[301][301];
int prefix[301][301];
int n, m;
string s1, s2; 

bool solve(int i, int j){
    if(dp[i][j] != -1) return dp[i][j];
    if(j == 0) return dp[i][j] = 1; // used up all of s2
    if(i == 0) return dp[i][j] = 0; // used up all of s1 without using all of s2

    if(solve(i-1, j)) return dp[i][j] = 1;

    for (int i1 = 1; i1 <= i; ++i1)
        // check for each prefix of s2 that is long enough to be a power string from s1
        for (int j1 = i1; j1 <= j && prefix[i-i1][j-j1] >= i1; j1 += i1)
            if(solve(i-i1, j-j1)) return dp[i][j] = 1;
    
    return dp[i][j] = 0;
}

int main(){
    cin.tie(0)->sync_with_stdio(0);
	cin.exceptions(cin.failbit);

    memset(dp, -1, sizeof dp);
    memset(prefix, 0, sizeof prefix);
    cin >> n >> m;
    cin >> s1 >> s2;

    // from s1[i], s2[j] how long is the prefix of matching characters
    rep(i, 0, n)
        rep(j, 0, m)
            // loop until either the characters stop matching or there are no characters to match
            while(i+prefix[i][j]<n && j+prefix[i][j] < m && s1[i+prefix[i][j]] == s2[j+prefix[i][j]])
                prefix[i][j]++;

    cout << (solve(n, m)?"yes":"no") << endl;
}