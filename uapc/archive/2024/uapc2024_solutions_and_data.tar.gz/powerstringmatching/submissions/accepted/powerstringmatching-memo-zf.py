#!/bin/python3

import functools

N, M = map(int, input().split())
s = input()
t = input()

match = []
for i in range(N):
  match.append([])
  for j in range(M):
    match[i].append(0)
    while i+match[i][j] < N and j+match[i][j] < M and s[i+match[i][j]] == t[j+match[i][j]]:
      match[i][j] += 1
# now match[i][j] is the length of the longest common prefix
# of s[i:] and t[j:] (i.e. how many characters we can match
# starting at these indices)

# check if s[i:j] == t[ii:jj] in O(1) time
def equals(i, j, ii, jj):
  return match[i][ii] >= max(j-i, jj-ii)

@functools.lru_cache(maxsize = None)
def solve(i, j):
  if j == 0: return True
  if i == 0: return False

  # try just deleting character i of s
  if solve(i-1, j): return True

  # now guess the suffix of s[:i] whose power should
  # match a suffix of t[:j]
  for k in range(1, i+1):
    for l in range(k, j+1, k):
      if not equals(i-k, i, j-l, j-l+k): break
      if solve(i-k, j-l): return True
  
  return False

print("yes" if solve(N, M) else "no")
