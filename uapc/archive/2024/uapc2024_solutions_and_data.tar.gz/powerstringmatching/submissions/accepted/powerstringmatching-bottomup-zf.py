#!/bin/python3

N, M = map(int, input().split())
s = input()
t = input()

match = []
for i in range(N):
  match.append([])
  for j in range(M):
    match[i].append(0)
    while i+match[i][j] < N and j+match[i][j] < M and s[i+match[i][j]] == t[j+match[i][j]]:
      match[i][j] += 1
# now match[i][j] is the length of the longest common prefix
# of s[i:] and t[j:] (i.e. how many characters we can match
# starting at these indices)

# check if s[i:j] == t[ii:jj] in O(1) time
def equals(i, j, ii, jj):
  return match[i][ii] >= max(j-i,jj-ii)

ans = [[False]*(M+1) for _ in range(N+1)]

for i in range(N+1):
  for j in range(M+1):
    if j == 0:
      ans[i][j] = True
    elif i > 0:
      # if i == 0, ans[i][j] was already set to false so
      # we can assume i > 0

      # first try just deleting the i'th character of s[:i]
      ans[i][j] = ans[i-1][j]
      # now guess the suffix of s[:i] whose power should
      # match a suffix of t[:j]
      for k in range(1, i+1):
        for l in range(k, j+1, k):
          if not equals(i-k, i, j-l, j-l+k): break
          if ans[i-k][j-l]: ans[i][j] = True
  
print("yes" if ans[N][M] else "no")
