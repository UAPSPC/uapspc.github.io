#include <bits/stdc++.h>

using namespace std;

const int MAXN = 310;

string s, t;
int memo[MAXN][MAXN], match[MAXN][MAXN];

bool equals(int i, int j, int ii, int jj) {
  return match[i][ii] >= max(j-i, jj-ii);
}

int solve(int i, int j) {
  int& x = memo[i][j];

  if (x == -1) {
    if (j == 0) x = 1;
    else if (i == 0) x = 0;
    else {
      x = solve(i-1, j);
      for (int k = 1; k <= i && !x; ++k)
        for (int l = k; l <= j && !x && equals(i-k, i, j-l, j-l+k); l += k)
          x = solve(i-k, j-l);
    }
  }


  return x;
}

int main() {
  int N, M; 
  cin >> N >> M >> s >> t;

  for (int i = 0; i < N; ++i)
    for (int j = 0; j < M; ++j)
      for (int& k = match[i][j]; k < min(N-i, M-j) && s[i+k] == t[j+k]; ++k);

  memset(memo, -1, sizeof(memo));

  cout << (solve(N, M) ? "yes" : "no") << endl;

  return 0;
}
