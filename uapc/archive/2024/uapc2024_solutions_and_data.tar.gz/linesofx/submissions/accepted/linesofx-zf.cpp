/*
  Testing a faster solution using bitmasks.

  These optimizations are not necessary to get it accepted, see
  linesofx-zf.py for a solution that is slower in practice
  but still sufficient.

  Running time: O(4^N * N^2), i.e. O(4^N) for the recursive calls
  and then O(N^2) for computing the hamming weight of an integer.
*/

#include <bits/stdc++.h>

using namespace std;

using ll = long long;

int N;
ll x_mask, o_mask, one = 1;
vector<ll> lines; // mask of the rows, columns, and diagonal entries

ll solve(int i, ll mask) {
  if (i == 2*N+2) {
    if (mask&o_mask) return 0;
    // __builtin_popcountll will return the number of 1 bits
    // in the binary representation of the given long long integer
    int blanks = N*N - __builtin_popcountll(mask | x_mask | o_mask);
    return 1ll << blanks;
  }

  return solve(i+1, mask) - solve(i+1, mask|lines[i]);
}

int main() {
  cin >> N;
  lines.assign(2*N+2, 0);

  // generate bitmasks for the rows
  for (int i = 0; i < N; ++i)
    for (int j = 0; j < N; ++j)
      lines[i] |= (one<<(i*N+j));

  // generate bitmasks for the columns
  for (int j = 0; j < N; ++j)
    for (int i = 0; i < N; ++i)
      lines[j+N] |= (one<<(i*N+j));
  
  // generate bitmask for forward diagonal
  for (int i = 0; i < N; ++i)
    lines[2*N] |= (one<<(i*N+i));
  
  // generate bitmask for back diagonal
  for (int i = 0; i < N; ++i)
    lines[2*N+1] |= (one<<(i*N + N-1-i));

  // read in the grid and generate bitmask for the positions
  // with ones and zeros
  for (int i = 0; i < N; ++i) {
    string row;
    cin >> row;
    for (int j = 0; j < N; ++j)
      if (row[j] == 'O') o_mask |= (one<<(i*N+j));
      else if (row[j] == 'X') x_mask |= (one<<(i*N+j));
  }

  ll no_row_count = 1ll << (N*N - __builtin_popcountll(x_mask | o_mask));
  cout << no_row_count - solve(0, 0) << endl;

  return 0;
}