n = int(input())
grid = [[c for c in input()] for _ in range(n)]

empties = 0
for row in grid:
    empties += row.count('.')

lines = []
for i in range(n):
    lines.append([(i, j) for j in range(n)])
    lines.append([(j, i) for j in range(n)])
lines.append([(i,i) for i in range(n)])
lines.append([(i,n-1-i) for i in range(n)])

# filled is the set of lines already filled in previous iterations
# and i is the line we're currently checking
def count(filled, i):
    if(i >= len(lines)): # no more lines, count number of arrangements with set
        # assumption: filled has no lines that contain O's
        coords = set()
        for idx in filled:
            for r, c in lines[idx]:
                coords.add((r,c))
        
        tot_empty = 0
        for r, c in coords:
            if(grid[r][c] == '.'):
                tot_empty += 1
        
        return 2**(empties-tot_empty)

    for r, c in lines[i]:
        if(grid[r][c] == 'O'):
            return count(filled, i+1)
    
    next_filled = filled.copy()
    next_filled.add(i)
    return count(filled, i+1) - count(next_filled, i+1)

print(2**empties-count(set(),0))
