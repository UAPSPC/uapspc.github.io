#!/bin/python3

# running time: O(4^N * N^2)
# there are many simple optimizations to speed this up in practice,
# they are not applied here

# Idea: let "lines" be the set of 2N+2 lines (rows, columns, diagonals)
# For each subset S of lines,
# Let c(S) be the number of grids that agree with G on the nonempty cells,
# have an 'X' on the cells covered by a line in S. If a line in S covers
# a 'O' in the given grid, then c(S) is 0.
#
# One would hope the sum of c({l}) over all lines l will give the answer,
# but this may double-count some solutions.
# So use the inclusion/exclusion formula:
# The answer is the sum of (-1)^{|S|+1}*c(S) over all nonempty subsets of lines.
#
# The recursive function below will compute this sum recursively.

N = int(input())
g = [input() for _ in range(N)]

dots = 0
for row in g:
  for entry in row:
    if entry == '.':
      dots += 1

# a list of all lines (i.e. rows/columns/diagonals)
# given as lists of coordinates (i,j) on that line
lines = []

for i in range(N):
  # i'th row
  lines.append([(i,j) for j in range(N)])

  # i'th column
  lines.append([(j,i) for j in range(N)])

# diagonals
lines.append([(i,i) for i in range(N)])
lines.append([(i,N-1-i) for i in range(N)])

# part of the inclusion/exclusion counting done recursively
def gen(i, cur):
  if i == len(lines):
    # the set of all coordinates lying on a line
    # represented by cur
    coords = {p for j in cur for p in lines[j]}
    
    # will be the number of dots that are not covered by
    # a line represented by "cur"
    open_dots = dots

    for ii,jj in coords:
      if g[ii][jj] == 'O':
        # if a line in "cur" contains a '0' in the given grid
        # we can't make them all 'X'
        return 0
      elif g[ii][jj] == '.':
        # this position is spanned by a line in "cur", so don't
        # count its dot
        open_dots -= 1
    
    # if we fix all entries covered by "cur" to X, there are still
    # "open_dots" remaining dots, this counts how many ways we can
    # fill them with X and O
    return 2**open_dots

  return gen(i+1, cur) - gen(i+1, cur+[i])

# gen(0, []) will actually compute the sum of (-1)^{|S|}*c(S) over all
# subsets of lines S. The formula below will remove the term with S being
# the empty set and will negate the rest.
print(2**dots - gen(0, []))
