#! /usr/bin/python3

print("Canadian!" if input()[-3:] == "eh?" else "Imposter!")
