#!/usr/bin/python3
print("ICmapnoasdtiearn!!"["eh?"==input()[-3:]::2])
