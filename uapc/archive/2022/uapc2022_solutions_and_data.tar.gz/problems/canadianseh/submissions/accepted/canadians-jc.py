#! /usr/bin/python3

print("Canadian!" if input().endswith("eh?") else "Imposter!")