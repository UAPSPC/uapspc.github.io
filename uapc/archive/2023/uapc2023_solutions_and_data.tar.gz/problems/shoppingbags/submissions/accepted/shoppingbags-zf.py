#!/bin/python3

T = int(input())
n1, n2 = map(int, input().split())
s1, s2 = map(int, input().split())

solve = [[0]*(n2+1) for _ in range(n1+1)]

for a in range(n1+1):
  for b in range(n2+1):
      if a+b == 0: continue
      solve[a][b] = a+b
      for j in range(min(b, T//s2)+1):
          i = min(a, (T-j*s2)//s1)
          solve[a][b] = min(solve[a][b], 1 + solve[a-i][b-j])


print(solve[n1][n2])
