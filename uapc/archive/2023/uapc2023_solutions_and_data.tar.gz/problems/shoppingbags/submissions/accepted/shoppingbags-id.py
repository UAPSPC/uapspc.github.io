#!/bin/python3
from sys import exit, setrecursionlimit
setrecursionlimit(6000)

T = int(input())
a = list(map(int, input().split()))
s = list(map(int, input().split()))

memo = [[-1 for _ in range(2001)] for _ in range(4001)]
def dp(numbags, num1):
    if memo[numbags][num1] != -1:
        return memo[numbags][num1]
    if numbags == 0:
        if num1 == 0:
            return 0
        else:
            return -5
    
    out = -5
    for x1 in range(min(num1+1, 5)):
        rem = T - x1*s[1]
        if rem < 0:
            continue
        rec = dp(numbags-1, num1-x1)
        if rec == -5:
            continue
        x0 = rem//s[0]
        out = max(out, rec+x0)
    memo[numbags][num1] = out
    return out

for out in range(5001):
    if dp(out, a[1]) >= a[0]:
        print(out)
        exit(0)
            
