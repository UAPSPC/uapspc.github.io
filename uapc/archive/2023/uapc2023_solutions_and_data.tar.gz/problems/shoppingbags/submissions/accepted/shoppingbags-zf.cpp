#include <bits/stdc++.h>

using namespace std;

const int MAXN = 5010;

int T, n1, n2, s1, s2;

int memo[MAXN][MAXN];

int solve(int a, int b) {
  int&x = memo[a][b];

  if (x == -1) {
    if (a == 0 && b == 0) x = 0;
    else {
      x = a+b;
      for (int j = 0; j <= b && j*s2  <= T; ++j) {
        int i = min((T - j*s2)/s1, a);
        if (i|j) x = min(x, 1+solve(a-i, b-j));
      }
    }
  }

  return x;
}

int main() {
  cin >> T >> n1 >> n2 >> s1 >> s2;

  memset(memo, -1, sizeof(memo));

  cout << solve(n1, n2) << endl;

  return 0;
}
