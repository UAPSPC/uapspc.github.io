#!/bin/python3

from sys import setrecursionlimit
setrecursionlimit(200000)

n, m = map(int, input().split())
adj = [set() for _ in range(n)]
out = 0
for _ in range(m):
    u, v, c = map(int, input().split())
    u -= 1
    v -= 1
    out += c
    adj[u].add((v, c))
    adj[v].add((u, c))

vis = [False for _ in range(n)]
def dfs(curr):
    o1 = 1
    o2 = len(adj[curr])
    o3 = 100000000
    for nxt in adj[curr]:
        o3 = min(o3, nxt[1])
        if not vis[nxt[0]]:
            vis[nxt[0]] = True
            rec = dfs(nxt[0])
            o1 += rec[0]
            o2 += rec[1]
            o3 = min(o3, rec[2])
    return (o1, o2, o3)

ogout = out
numcomps = 0
for i in range(n):
    if not vis[i]:
        numcomps += 1
        vis[i] = True
        rec = dfs(i)
        if rec[0]*2 == rec[1]:
            out -= rec[2]

if numcomps == 1:
    print(ogout)
else:
    print(out)
