#!/bin/python3

import sys

sys.setrecursionlimit(200000)

INF = 10**20

n, m = map(int, input().split())

uf = list(range(n))
rank = [1]*n
mn = [INF]*n
frozen = [False]*n

def find(v):
  if uf[v] != v: uf[v] = find(uf[v])
  return uf[v]

def addedge(u, v, d):
  u, v = find(u), find(v)
  if rank[v] < rank[u]: u, v = v, u
  frozen[v] = frozen[v] or frozen[u] or u == v
  mn[v] = min(mn[v], mn[u], d)
  uf[u] = v
  if u != v and rank[u] == rank[v]: rank[v] += 1

tot = 0
for _ in range(m):
  u, v, d = map(int, input().split())
  addedge(u-1, v-1, d)
  tot += d

reps = [i for i in range(n) if uf[i] == i]

if len(reps) == 1: print(tot)
else: print(tot - sum(mn[i] for i in reps if frozen[i]))