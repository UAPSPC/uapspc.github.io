#!/bin/python3

from sys import exit, setrecursionlimit

setrecursionlimit(200000)

n, m = map(int, input().split())
par = [i for i in range(n)]
numverts = [1 for _ in range(n)]
numedges = [0 for _ in range(n)]
minedge = [1000000000 for _ in range(n)]

def getPar(x):
    if par[x] == x:
        return x
    par[x] = getPar(par[x])
    return par[x]

def Union(x, y, c):
    x = getPar(x)
    y = getPar(y)
    if x == y:
        numedges[y] += 1
        minedge[y] = min(minedge[y], c)
        return
    numedges[y] += numedges[x]+1
    numverts[y] += numverts[x]
    minedge[y] = min(minedge[y], min(minedge[x], c))
    par[x] = y


out = 0
for _ in range(m):
    u, v, c = map(int, input().split())
    u -= 1
    v -= 1
    out += c
    Union(u, v, c)

numcomps = 0
for i in range(n):
    if getPar(i) == i:
        numcomps += 1
if numcomps == 1:
    print(out)
    exit(0)

maxverts = 0
for i in range(n):
    if getPar(i) == i:
        maxverts = max(maxverts, numverts[i])
        if numverts[i] == numedges[i]:
            out -= minedge[i]
print(out)