#include <bits/stdc++.h>

using namespace std;

struct player {
  priority_queue<int, vector<int>, std::greater<int>> cards;
  string name;
};

int main() {
  int N, M, P;
  cin >> N >> M >> P;

  list<player> players(N);

  // read in the players
  for (player& p : players) {
    cin >> p.name;
    for (int i = 0; i < M; ++i) {
      int x;
      cin >> x;
      p.cards.push(x);
    }
  }

  // returns a tuple for the player that can be compared via < with other tuples
  // to see which player will lose their card
  auto tup = [&](list<player>::iterator it) { return tie(it->cards.top(), it->name); };

  while (players.size() > 1) {
    // get an iterator pointing to the player who should lose their card
    auto mn = players.begin();
    for (auto it = players.begin(); it != players.end(); ++it)
      if (tup(it) < tup(mn))
        mn = it;

    // mark all cards of the players that didn't lose one
    // and remove the card from the player that lost theirs
    for (auto it = players.begin(); it != players.end(); ++it) {
      if (it != mn) it->cards.push(it->cards.top() + P);
      it->cards.pop();
    }

    // if the player that lost theirs has no more, they are gone
    if (mn->cards.size() == 0) {
      cout << mn->name << ' ';
      players.erase(mn);
    }
  }

  // output the sole player remaining
  cout << players.begin()->name << endl;

  return 0;
}