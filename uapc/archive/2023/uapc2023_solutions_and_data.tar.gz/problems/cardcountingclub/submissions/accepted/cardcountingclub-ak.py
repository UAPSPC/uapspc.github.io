#!/bin/python3
import heapq

simulation = {}
result = []
nameList = []

numPlayers = 0
lenLists = 0
penalty = 0

def readInput():
    global numPlayers, lenLists, penalty, simulation, result, nameList
    inp = list( map( int, input().split() ) )
    numPlayers = inp[ 0 ]
    lenLists = inp[ 1 ]
    penalty = inp[ 2 ]

    inpBuf = {}
    for n in range( numPlayers ):
        inp = input().split()
        nameList.append( inp[ 0 ] )
        inpBuf[ inp[ 0 ] ] = list( map( int, inp[ 1 : ] ) )

    nameList.sort()

    for n in range( numPlayers ):
        heap = []
        for num in inpBuf[ nameList[ n ] ]:
            heapq.heappush( heap, num )
        simulation[ n ] = heap


def simulate():
    global numPlayers, lenLists, penalty, simulation, result, nameList
    numCurrPlayers = numPlayers
    while numCurrPlayers:
        # Step 1: Set up the single iteration state
        minVal = -1
        minIdx = numPlayers

        # Step 2: Iterate through all the players to figure out who has the
        # smallest value in their hand
        for k, v in simulation.items():
            val = v[ 0 ]
            if val < minVal or minVal == -1:
                minVal = val
                minIdx = k
            elif val == minVal and k < minIdx:
                minIdx = k

        # Step 3: Let the winner progress
        heapq.heappop( simulation[ minIdx ] )
        if len( simulation[ minIdx ] ) == 0:
            result.append( minIdx )
            del simulation[ minIdx ]
            numCurrPlayers -= 1
        
        # Step 4: Iterate through all the losing players and apply the penalty
        # to their hand. Note: iterating through keys only as I will be changing
        # the values and don't remember how well python handles mutation of a
        # currently iterated collection
        for k in simulation.keys():
            if k == minIdx:
                continue
            val = heapq.heappop( simulation[ k ] )
            heapq.heappush( simulation[ k ], val + penalty )


def generateOutput():
    global numPlayers, result, nameList
    outp = []
    for i in range( numPlayers ):
        outp.append( nameList[ result[ i ] ] )
    print( *outp )


def main():
    readInput()
    simulate()
    generateOutput()
    

if __name__ == "__main__":
    main()
