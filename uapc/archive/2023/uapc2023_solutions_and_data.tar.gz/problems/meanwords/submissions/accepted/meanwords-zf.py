#!/bin/python3

words = [input() for _ in range(int(input()))]

accum = [[] for _ in range(max(len(w) for w in words))]

for w in words:
  for i in range(len(w)):
    accum[i].append(ord(w[i]))

print("".join([chr(sum(a)//len(a)) for a in accum]))
