#!/bin/python3
n = int( input() )
words = [ input() for _ in range( n ) ]
maxlen = 0
for word in words:
    if len( word ) > maxlen:
        maxlen = len( word )
sums = [ 0 ] * maxlen
counts = [ 0 ] * maxlen
for word in words:
    for i, char in enumerate( word ):
        sums[ i ] += ord( char )
        counts[ i ] += 1
outp = [ chr( sums[ i ] // counts[ i ] ) for i in range( maxlen ) ]
print( "".join( outp ) )
