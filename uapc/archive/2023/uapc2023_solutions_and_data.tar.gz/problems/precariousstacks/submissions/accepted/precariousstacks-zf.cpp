#include <bits/stdc++.h>

using namespace std;

struct event {
  int x, i;
  bool start;
  bool operator<(const event& rhs) const {
    if (x != rhs.x) return x < rhs.x;
    if (start != rhs.start) return !start;
    return false;
  }
};

int main() {
  int n;
  cin >> n;

  vector<int> x(n), s(n);
  vector<event> events;
  for (int i = 0; i < n; ++i) {
    cin >> x[i] >> s[i];
    events.push_back({x[i], i, true});
    events.push_back({x[i] + s[i], i, false});
  }
  
  sort(events.begin(), events.end());
  
  set<int> sweepline;

  vector<vector<int>> dep(n);
  
  for (auto [x, i, start] : events) {
    if (start) {
      auto it = sweepline.lower_bound(i);
      if (it != sweepline.begin()) dep[i].push_back(*prev(it));
      if (it != sweepline.end()) dep[*it].push_back(i);
      sweepline.insert(i);
    }
    else {
      auto it = sweepline.find(i);
      assert(it != sweepline.end());
      if (next(it) != sweepline.end() && it != sweepline.begin()) dep[*next(it)].push_back(*prev(it));
      sweepline.erase(it);
    }
  }

  long long final = 0;
  vector<long long> ans(n, 0);
  for (int i = 0; i < n; ++i) {
    for (auto j : dep[i])
      ans[i] = max(ans[i], ans[j]);
    ans[i] += s[i];
    final = max(final, ans[i]);
    cout << final << endl;
  }


  return 0;
}