#!/bin/python3

# COMMENT: There is a simpler approach in C++ using ordered sets (i.e. the set<> data type)
# But such data structures are not in the standard library for Python, so here is a way to do it
# using segment trees.

n = int(input())

x, s = [], []

# Will store the distinct start coordinates as (x,1) and the distinct end coordinates as (x,0).
# So same starts or same ends are regarded as equal but if a square ends at x and another starts
# at x, the "end" will be considered to come before before the "start" (adjacent squares do not stick).
vals = set()

for _ in range(n):
  square_x, square_s = map(int, input().split())
  x.append(square_x)
  s.append(square_s)
  vals.add((square_x, 1))
  vals.add((square_x + square_s, 0))

# Get a mapping from each start/end point to their index in the sorted order.
vals = sorted(vals)
rmap = {vals[i]:i for i in range(len(vals))}

# BEGIN LAZY SEGMENT TREE STUFF

# Get the smallest power of 2 that is >= len(vals) for the segtree.
SEGN = len(vals)
while SEGN&(SEGN-1): SEGN += 1
segtree = [0]*(2*SEGN)
lazy = [-1]*(2*SEGN)

# If "node" is not a leaf, push the lazy updates to its children.
def push(low, high, node):
  if lazy[node] == -1: return

  segtree[node] = lazy[node]
  if low+1 < high:
    lch, rch = 2*node+1, 2*node+2
    lazy[lch] = max(lazy[lch], lazy[node])
    lazy[rch] = max(lazy[rch], lazy[node])
  lazy[node] = -1

# All indices in the range [l, r) should now have height nh
def update(l, r, nh, low = 0, high = SEGN, node = 0):
  if r <= low or high <= l:
    return 0
  elif l <= low and high <= r:
    segtree[node] = lazy[node] = max(segtree[node], lazy[node], nh)
  else:
    mid = (low+high)>>1
    lch, rch = 2*node+1, 2*node+2
    update(l, r, nh, low, mid, lch)
    update(l, r, nh, mid, high, rch)
    segtree[node] = max(segtree[2*node+1], segtree[2*node+2])

  return segtree[node]

# What is the maximum height stored in the range [l, r)
def query(l, r, low = 0, high = SEGN, node = 0):
  push(low, high, node)

  if r <= low or high <= l:
    return 0
  elif l <= low and high <= r:
    return segtree[node]
  else:
    mid = (low+high)>>1
    return max(query(l, r, low, mid, 2*node+1), query(l, r, mid, high, 2*node+2))

# END SEGMENT TREE STUFF

ans = 0

# For each square in turn
for i in range(n):
  # Get the indices of its start and end sides.
  l, r = rmap[(x[i], 1)], rmap[(x[i] + s[i], 0)]+1
  
  # Get the current maximum height in this range.
  height = query(l, r)

  # print(x[i], s[i], l, r, height, ":", segtree)

  # The height of this square when it rests on the pile below.
  new_height = height + s[i]
  ans = max(ans, new_height)
  print(ans)

  # All indices in this range should have their height set to new_height.
  update(l, r, new_height)
# print(segtree)

