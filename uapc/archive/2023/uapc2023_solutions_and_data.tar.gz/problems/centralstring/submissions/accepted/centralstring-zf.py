#!/bin/python3

def update(j):
    for i in range(N):
        if s[j] != words[i][j]: differ[i].add(j)
        elif j in differ[i]: differ[i].remove(j)

def solve(rem):
    i = 0
    for j in range(1,N):
        if len(differ[j]) > len(differ[i]): i = j

    if len(differ[i]) <= D:
        print("".join(map(chr, s)))
        quit()

    if len(differ[i]) > D+rem:
        return

    different = list(differ[i])
    for j in different:
        old = s[j]
        s[j] = words[i][j]
        update(j)

        solve(rem-1)

        s[j] = old
        update(j)

N, L, D = map(int, input().split())
words = [list(map(ord, input())) for _ in range(N)]

differ = [set() for _ in range(N)]

s = words[0]
for j in range(L): update(j)
solve(D)

print(0)
