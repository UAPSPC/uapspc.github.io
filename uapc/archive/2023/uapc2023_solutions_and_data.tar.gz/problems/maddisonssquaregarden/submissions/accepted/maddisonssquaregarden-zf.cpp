/*
  Basic strategy: binary search for the largest garden side length that is feasible.

  For each proposed garden side length, compute the travel time for each pair and ensure it is feasible.

  To do travel time:
    Easy case: the line from home to work is horizontal or vertical.
      Still have to determine how much time is in the garden, but it's simpler.

    Otherwise: parameterize the line as (1-t)*home + t*work (so t == 0 is home and t == 1 is work)
     Solve for the x-component = -l and l as well as the y-component = -l and l. These give intervals
     where the x-coordinate and the y-coordinate of the parameterized path lie within the garden's span
     along that axis. So intersecting these intervals gives us the time in the parameterization that is
     in the garden.
*/

#include <bits/stdc++.h>

using namespace std;

const int MAXN = 100100;
const double EPS = 1e-9;

struct point {
  double x, y;
};

int n;
double delta;
double t[MAXN];
point home[MAXN], work[MAXN];

// returns t clamped to the [0,1] interval
double clamp(double t) { return max(min(t, 1.0), 0.0); }

// distance between points
double dist(point a, point b) {
  double dx = a.x-b.x, dy = a.y-b.y;
  return sqrt(dx*dx + dy*dy);
}

// find the first and last points t1 <= t2 in the interval [0,1]
// such that (1-t)*x1 + t*x2 lies in the garden with side length l
// if there is no such point in the interval, will set t1 = t2 = 0.0
// assumes x1 != x2
void get_ival(double x1, double x2, double& t1, double& t2, double l) {
  t1 = (0.5-l-x1)/(x2-x1);
  t2 = (0.5+l-x1)/(x2-x1);

  // cout << x1 << ' ' << x2 << endl;
  // cout << t1 << ' ' << t2 << endl;

  // the the points lie outside the interval [0,1]
  if (max(t1, t2) < 0.0 || min(t1, t2) > 1.0) {
    t1 = t2 = 0.0;
  }
  else {
    t1 = clamp(t1);
    t2 = clamp(t2);
    if (t1 > t2) swap(t1, t2);
  }
}

// the line from home -> work passes through the garden at points (1-t1)*home + t1*work
// and (1-t2)*home + t2*work. What is the travel time?
double answer(point home, point work, double t1, double t2) {
  point g1 = {(1-t1)*home.x + t1*work.x, (1-t1)*home.y + t1*work.y};
  point g2 = {(1-t2)*home.x + t2*work.x, (1-t2)*home.y + t2*work.y};

  double calc = dist(home, g1)/0.1 + dist(g1, g2)/(0.1*delta) + dist(g2, work)/0.1;

  // cerr << g1.x << ' ' << g1.y << ' ' << g2.x << ' ' << g2.y << " : " << t1 << ' ' << t2 << " : " << calc << endl;

  return calc;
}

// the line is vertical (home.x == work.x)
double vertical(point home, point work, double l) {
  // check if home and work are the same
  if (abs(home.y - work.y) < EPS) return 0.0;

  // is the vertical line to the left or right of the garden?
  if (home.x < 0.5-l || home.x > 0.5+l) return abs(home.y - work.y)/0.1;

  double t1, t2;
  get_ival(home.y, work.y, t1, t2, l);

  return answer(home, work, t1, t2);
}

// what is the travel time from home to work given a garden with side length 2*l?
double travel(point home, point work, double l) {
  // special cases: the direct line from home to work is horizontal or vertical
  if (abs(home.x - work.x) < EPS) return vertical(home, work, l);
  if (abs(home.y - work.y) < EPS) return vertical({home.y, home.x}, {work.y, work.x}, l);

  double tx1, tx2, ty1, ty2;
  get_ival(home.x, work.x, tx1, tx2, l);
  get_ival(home.y, work.y, ty1, ty2, l);

  // compute the intersections of the intervals [tx1, tx2] and [ty1, ty2] to
  // determine the actual time in the parameterization spent in the garden
  double t1 = max(tx1, ty1), t2 = min(tx2, ty2);

  // if the intervals were disjoint, set them to the same value so the effective time in the garden is 0
  if (t1 > t2) t1 = t2 = 0.0;
  return answer(home, work, t1, t2);
}

// if the garden has side length = 2*l, will everyone make it to work on time?
bool query(double l) {
  for (int i = 0; i < n; ++i)
    if (travel(home[i], work[i], l) > t[i])
      return false;
  return true;
}

int main() {
  cout.setf(ios::fixed);
  cout.precision(10);

  cin >> n >> delta;
  for (int i = 0; i < n; ++i) cin >> home[i].x >> home[i].y >> work[i].x >> work[i].y >> t[i];

  // double x = travel(home[0], work[0], 0.5);
  // cout << x << endl;
  // return 0;

  double lo = 0.0, hi = 0.5;

  // even with no garden, some people can't make it
  if (!query(lo)) {
    // should not get here, the input guarantees everyone can get to work on time if there is no garden
    assert(false);
  }
  if (query(hi)) {
    cout << 1.0 << endl;
    return 0;
  }

  // invariant: a garden of length 2*lo is ok but a garden of side length 2*hi is not ok
  while (lo + EPS < hi) {
    double mid = (lo+hi)*0.5;

    if (query(mid)) lo = mid;
    else hi = mid;
  }

  // within enough tolerance of the correct answer
  cout << 2*lo << endl;

  return 0;
}