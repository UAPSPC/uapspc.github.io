#!/bin/python3

import math

def case2(x_0, y_1, t, delta):
    # Assumes problem is rotated to y_0 = 0 and x_1 = 1.
    y_0 = 0
    x_1 = 1

    # Find the baseline time to get between the two points.
    d = math.sqrt((y_1 - y_0)**2 + (x_1 - x_0)**2)
    if d > t: # If it's not possible even with no garden, return -1.
        return -1
    # The permitted excess time spent in the garden is t-d
    # Total time to walk is t = d-h + delta * h where h is the distance in the garden.
    # Recall we have inverted delta.
    # So our maximum allowed distance in the garden is:
    h = (t-d)/(delta - 1)
    # The slope of the line between (x_0, y_0) and (x_1, y_1) is:
    m = (y_1 - y_0)/(x_1 - x_0)
    # The angle off the x-axis, and therefore the angle we intercept the garden is:
    angle = math.atan(m)
    # The equation of the line is y - y_0 = m(x-x_0) or x = (y - y_0)/m + x_0.
    # So we intercept a garden of side length \ell = 2r at ((0.5 - r)/m + x_0, 0.5 - r).
    # We remain in the garden for h = ((0.5 + r) - ((0.5 - r)/m + x_0))/math.cos(angle).
    # We solve for r to get:
    r = ((math.cos(angle) * h) + x_0 - (0.5 * (1 - (1/m))))/(1 + (1/m))
    return min(2*r, 1)

def case3(x_0, x_1, t, delta):
    # Assumes problem is rotated to y_0 = 0 and y_1 = 1.
    # Also assumes that the line (x_0, 0) - (x_1, 1) goes below (0.5,0.5).
    y_0 = 0
    y_1 = 1

    # This is all the same as Case 2:
    # Find the baseline time to get between the two points.
    d = math.sqrt((y_1 - y_0)**2 + (x_1 - x_0)**2)
    if d > t: # If it's not possible even with no garden, return -1.
        return -1
    h = (t-d)/(delta - 1) # Max distance in garden.
    m = (y_1 - y_0)/(x_1 - x_0) # Slope of line.
    angle = math.atan(m) # Angle of intercept.

    # We still intercept at ((0.5 - r)/m + x_0, 0.5 - r).
    # However, we might leave out the side or maybe out the top, so we have two subcases here.
    # The case where we come out of the side is the same as before.
    r1 = ((math.cos(angle) * h) + x_0 - (0.5 * (1 - (1/m))))/(1 + (1/m))
    # However, if we leave the garden earlier than expected, r1 overshoots the time it would take.
    # We can instead solve for r when we leave the garden through the top.
    # In this case, we are in the garden for h = (2*r)/math.sin(angle).
    # It's much simpler and doesn't depend on x_0 because we are going through the whole thing.
    # It doesn't matter where we enter.
    r2 = (h * math.sin(angle))/2
    # r2 is pessimistic when we leave the garden early through the side.
    # Therefore the true value is the MAXIMUM of the two.
    r = max(r1, r2)
    return min(2*r, 1)

def runInstance(x_0, y_0, x_1, y_1, t, delta):
    #
    # Case 0: delta = 1, so the size of the garden doesn't matter.
    #
    if (delta == 1):
        return 1 if math.sqrt((y_1 - y_0)**2 + (x_1 - x_0)**2) <= t else -1

    #
    # Case 1: Points are on the same side of the unit square.
    #
    if (x_0 == 1 and x_1 == 1) or (x_0 == 0 and x_1 == 0): # Just check feasibility along whatever axis.
        return 1 if abs(y_0 - y_1) <= t else -1
    if (y_0 == 1 and y_1 == 1) or (y_0 == 0 and y_1 == 0): # Just check feasibility along whatever axis.
        return 1 if abs(x_0 - x_1) <= t else -1

    # Mirror the problem to have y_0 = 0, (the first point on the x axis,) for simplicity.
    if y_0 == 0: # y_0 = 0 as desired.
        pass
    elif y_0 == 1: # Flip over y = 0.5.
        x_0, y_0 = x_0, 1 - y_0
        x_1, y_1 = x_1, 1 - y_1
    elif x_0 == 0: # Flip over y = x.
        x_0, y_0 = y_0, x_0
        x_1, y_1 = y_1, x_1
    elif x_0 == 1: # Flip over y = x then y = 0.5.
        x_0, y_0 = y_0, 1 - x_0
        x_1, y_1 = y_1, 1 - x_1
    else:
        print("Shouldn't get here")
        exit(1)

    #
    # Case 2: Points are on adjacent sides of the unit square.
    # Mirror the problem to ensure that x_1 = 1, again for simplicity.
    #
    if x_1 == 1: # x_1 = 1 as desired, so handle Case 2 immediately.
        return case2(x_0, y_1, t, delta)
    elif x_1 == 0: # Flip over x = 0.5, then handle Case 2.
        x_0, y_0 = 1 - x_0, y_0
        x_1, y_1 = 1 - x_1, y_1
        return case2(x_0, y_1, t, delta)

    #
    # Case 3: Points are on opposite sides of the unit square.
    # Check for the degenerate case of the points being on the same vertical line, then continue.
    # Mirror the problem to ensure that the line is below (0.5, 0.5) and x_0 < x_1.
    # It's also easiest if 0.5 <= x_0, at least for me.
    #
    if y_1 == 1:
        pass
    else:
        print("Shouldn't get here")
        exit(1)

    if x_0 == x_1: # Case 3a: Points are on the same vertical line.
        if t < 1: # Easy check for feasibility.
            return -1
        # Otherwise, maximum distance in garden is h = (t-1)/(delta - 1).
        h = (t - 1)/(delta - 1)
        # The maximum side length for this instance is either h,
        # or the garden touching the line if side length h doesn't reach it.
        return max(h, 2*(abs(0.5 - x_0)))

    # We want the points such that the line between goes under (0.5, 0.5) and x_0 < x_1.
    # Prove to yourself this works if you want.
    if x_0 < (1-x_1): # If necessary, flip over x = 0.5.
        x_0, y_0 = 1 - x_0, y_0
        x_1, y_1 = 1 - x_1, y_1
    if x_0 > x_1: # If still not how we want, flip over y = 0.5.
        x_0, x_1 = x_1, x_0

    return case3(x_0, x_1, t, delta) # Problem should be in the right form.

if __name__ == "__main__":
    # Get parameters
    N, delta = map(float, input().split())
    N = int(N)

    # Setup output
    minimums = [1]

    # Run for each
    for i in range(N):
        x_0, y_0, x_1, y_1, t = map(float, input().split())
        # Note that we move t to units per minute and take the inverse of delta.
        r = runInstance(x_0, y_0, x_1, y_1, t/10, 1/delta)
        #if r < 0.1:
            #print(r)
            #print(x_0, y_0, x_1, y_1, t)
            #print(i)
        minimums.append(r)

    # Output result
    print(min(minimums), flush=True)
