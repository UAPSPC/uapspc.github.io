#!/bin/python3

base = int(input())
digits = input().split()
number = input()

answer = 0
start = 0
for i in range(len(number)):
  if number[start:i+1] in digits != -1:
    answer = answer*base + digits.index(number[start:i+1])
    start = i+1
print(answer)
