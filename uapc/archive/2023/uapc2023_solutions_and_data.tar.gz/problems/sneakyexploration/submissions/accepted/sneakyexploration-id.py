#!/bin/python3

from queue import PriorityQueue
from sys import exit

n = int(input())
adj = [[] for _ in range(n+1)]
deg = [0 for _ in range(n)]
used = [False for _ in range(n)]
for _ in range(n-1):
    u, v = map(int, input().split())
    u -= 1
    v -= 1
    adj[u].append(v)
    adj[v].append(u)
    deg[u] -= 1
    deg[v] -= 1

q = PriorityQueue()
for i in range(n):
    q.put((deg[i], i))
toadd = []
out = []
for _ in range(n):
    nxt = -1
    while nxt == -1:
        if q.empty():
            print(-1)
            exit(0)
        top = q.get()
        if deg[top[1]] == top[0]:
            nxt = top[1]
    for x in toadd:
        q.put((deg[x], x))
    toadd = []
    out.append(nxt+1)
    used[nxt] = True
    for x in adj[nxt]:
        if not used[x]:
            deg[x] += 1
            toadd.append(x)

print(*out)


