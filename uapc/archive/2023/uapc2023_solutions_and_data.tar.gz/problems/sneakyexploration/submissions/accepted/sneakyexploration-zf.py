#!/bin/python3

import random

N = int(input())
g = [set() for _ in range(N+1)]
if N == 1:
  print(1)
  exit(0)

for _ in range(N-1):
  u, v = map(int, input().split())
  g[u].add(v)
  g[v].add(u)

rdeg = sorted(range(1,N+1), key = lambda v : len(g[v]))[::-1]

if len(g[rdeg[0]]) == N-1:
  print(-1)
  exit(0)

fcount = [0]
ans = [rdeg[0]]
rem = list(range(1, N+1))
rem.remove(ans[0])
nbr_1 = [v for v in range(1, N+1) if v != ans[0] and v not in g[ans[0]]]

while len(ans) < N:
  if len(ans) == 1:
    v = random.choice(nbr_1)
    rem.remove(v)
    ans.append(v)
    fcount.append(0)
  else:
    i = random.randint(0, len(rem)-1)

    if rem[i] in g[ans[-1]] or fcount[-1] >= 2:
      rem.append(ans[-1])
      ans.pop()
      fcount.pop()
      fcount[-1] += 1
    else:
      fcount.append(0)
      ans.append(rem[i])
      rem[i], rem[-1] = rem[-1], rem[i]
      rem.pop()

assert(sorted(ans) == list(range(1, N+1)))
for i in range(N-1): assert ans[i] not in g[ans[i+1]]

print(*ans)
