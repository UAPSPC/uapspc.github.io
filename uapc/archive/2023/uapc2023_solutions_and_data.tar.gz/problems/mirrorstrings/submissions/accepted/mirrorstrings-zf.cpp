#include <bits/stdc++.h>

using namespace std;

using ll = long long;

const ll MOD = 1'000'000'007;

int main() {
  int l, r;
  cin >> l >> r;

  ll ans = 0, pow2 = 1, pow5 = 1;
  for (int i = 1; i <= r; ++i) {
    if (i&1) {
      pow2 = (2*pow2)%MOD;
      pow5 = (5*pow5)%MOD;
    }

    // can only use lowercase (2 characters) or only uppercase (5 characters)
   if (i >= l) ans = (ans + pow2 + pow5)%MOD;
  }

  cout << ans << endl;

  return 0;
}