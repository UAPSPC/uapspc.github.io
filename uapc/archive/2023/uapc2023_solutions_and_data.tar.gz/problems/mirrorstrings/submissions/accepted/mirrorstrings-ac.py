#!/bin/python3

MOD=1000000007
 
m, n = map(int, input().split())
ans = 0
res1 = 1 
res2 = 1
for i in range(1, n + 1):
    if (i &1 ):
      res1 = (2*res1) % MOD
      res2 = (5*res2) % MOD
    if (i >= m) :
        ans = (ans + res1 + res2) % MOD
  
print(ans)
