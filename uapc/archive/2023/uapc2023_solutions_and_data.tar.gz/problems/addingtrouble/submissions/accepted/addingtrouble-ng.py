#!/bin/python3
a, b, c = map(int, input().split())

print('correct!' if a + b == c else 'wrong!')