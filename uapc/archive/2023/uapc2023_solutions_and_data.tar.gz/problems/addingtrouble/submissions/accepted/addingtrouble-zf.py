#!/bin/python3
A,B,C = map(int,input().split())
print("wrong!" if A+B-C else "correct!")