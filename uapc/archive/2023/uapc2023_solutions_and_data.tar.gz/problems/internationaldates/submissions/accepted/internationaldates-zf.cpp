#include <bits/stdc++.h>

using namespace std;

int main() {
  int d, m;
  char x;
  cin >> d >> x >> m;
  string ans[] = {"", "US", "EU", "either"};
  cout << ans[(int(m<=12)<<1) + int(d<=12)] << endl;
  return 0;
}