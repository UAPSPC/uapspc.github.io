#!/bin/python3

a, b, _ = map(int, input().split('/'))

if a > 12:
    print('EU')
elif b > 12:
    print('US')
else:
    print('either')