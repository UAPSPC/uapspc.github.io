#include <bits/stdc++.h>

using namespace std;

int solve() {
  int T, N;
  cin >> T >> N;
  
  vector<bool> left_cover(T, false), right_cover(T, false);
  
  // nl, nr = total # of experts of each type
  int nl = 0, nr = 0;
  for (int i = 0; i < N; ++i) {
    int x;
    char l;
    cin >> x >> l;
    --x;

    if (l == 'L') {
      left_cover[x] = true;
      ++nl;
    }
    else {
      right_cover[x] = true;
      ++nr;
    }
  }

  // tl, tr, tb = total # of topics covered by only L, only R, or both
  int tl = 0, tr = 0, tb = 0;
  for (int i = 0; i < T; ++i)
    if (left_cover[i] && right_cover[i]) ++tb;
    else if (left_cover[i]) ++tl;
    else if (right_cover[i]) ++tr;
    else return -1; // topic not covered by anyone

  // we must use tl 'L' experts and tr 'R' experts on the one-leaning only topics

  // # of each expert leaning used
  int used_l = tl, used_r = tr;

  // # of topics that are not yet covered, each has an expert of either leaning
  int rem_t = tb;

  // while some topic is uncovered, use an expert from the "deficient" side to cover one
  // if all topics are covered, then still use an expert from the "deficient" side
  // since we need to balance the coverage
  while (rem_t > 0 || used_l != used_r) {
    if (used_l < used_r) {
      if (used_l == nl) return -1;
      ++used_l;
    }
    else {
      if (used_r == nr) return -1;
      ++used_r;
    }
    if (rem_t > 0) --rem_t;
  }

  return used_l + used_r;
}

int main() {
  cout << solve() << endl;

}