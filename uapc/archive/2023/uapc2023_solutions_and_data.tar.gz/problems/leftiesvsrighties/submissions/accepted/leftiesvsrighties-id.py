#!/bin/python3
from sys import exit
t, n = map(int, input().split())
a = [[0, 0] for _ in range(t)]
for _ in range(n):
    inp = input().split()
    topic = int(inp[0]) - 1
    c = inp[1]
    if c == 'L':
        a[topic][0] += 1
    else:
        a[topic][1] += 1

nleft = 0
nright = 0
for i in range(t):
    if a[i][0] + a[i][1] == 0:
        print(-1)
        exit(0)
    if a[i][0] == 0:
        nright += 1
        a[i][1] -= 1
    elif a[i][1] == 0:
        nleft += 1
        a[i][0] -= 1

for i in range(t):
    if a[i][0] != 0 and a[i][1] != 0:
        if nleft < nright:
            a[i][0] -= 1
            nleft += 1
        else:
            a[i][1] -= 1
            nright += 1

for i in range(t):
    while nleft < nright and a[i][0] != 0:
        nleft += 1
        a[i][0] -= 1
    while nleft > nright and a[i][1] != 0:
        nright += 1
        a[i][1] -= 1
if nleft == nright:
    print(nleft*2)
else:
    print(-1)