#!/bin/python3

s = input()

print(s[0], end='')

for i in range(1, len(s)):
    if s[i] != s[i - 1]:
        print(s[i], end='')
print()