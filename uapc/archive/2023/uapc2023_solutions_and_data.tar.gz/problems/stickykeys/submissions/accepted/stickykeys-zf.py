#!/bin/python3

s = "#"+input()

print("".join([s[i] for i in range(1, len(s)) if s[i] != s[i-1]]))